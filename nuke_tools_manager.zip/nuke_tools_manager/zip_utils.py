# zip_utils.py
"""
Nuke Tools Manager — Zip / Unzip / Install utilities
-----------------------------------------------------
Public API
----------
  zip_folder(folder_path, output_zip=None, include_extensions=None)
      → str  (path to created .zip)

  list_zip_contents(zip_path)
      → list[dict]  [{name, size, compress, date}, …]

  install_from_zip(zip_path, install_dir=None, overwrite=True)
      → str  (install_dir)

  install_from_folder(folder_path, install_dir=None, overwrite=True, progress_cb=None)
      → str  (install_dir)
      Directly copies a folder into the tools directory (no zip needed).

  uninstall_tool(tool_name)
      → bool

  get_installed_tools()
      → dict  {name: {install_dir, zip_source, installed_at, files}}

  register_tool_path(path)
      Adds path to sys.path and nuke.pluginAddPath()

  register_nuke_plugin_path(path, target_nuke_version, major_only=True)
      Writes a persistent nuke.pluginAddPath() call into ~/.nuke/init.py,
      optionally scoped to a specific Nuke major version.

  register_all_installed()
      Calls register_tool_path() for every entry in the manifest.
"""

import os
import sys
import zipfile
import shutil
import json
import hashlib
from pathlib import Path
from datetime import datetime

# ── Default paths ──────────────────────────────────────────────────────────────
NUKE_DIR       = os.path.join(os.path.expanduser('~'), '.nuke')
TOOLS_DIR      = os.path.join(NUKE_DIR, 'tools')
MANIFEST_FILE  = os.path.join(TOOLS_DIR, 'manifest.json')


# ── Internal helpers ───────────────────────────────────────────────────────────

def _ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def _file_md5(path):
    h = hashlib.md5()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def _load_manifest():
    if os.path.exists(MANIFEST_FILE):
        try:
            with open(MANIFEST_FILE, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def _save_manifest(data):
    _ensure_dir(TOOLS_DIR)
    with open(MANIFEST_FILE, 'w') as f:
        json.dump(data, f, indent=2)


# ── Public: Zip ────────────────────────────────────────────────────────────────

def zip_folder(folder_path, output_zip=None, include_extensions=None):
    """
    Pack a tools folder into a .zip archive.

    Parameters
    ----------
    folder_path : str
        Absolute path to the folder you want to zip.
    output_zip : str | None
        Destination .zip path. Defaults to <folder_path>.zip
        in the same parent directory.
    include_extensions : list[str] | None
        If provided, only files whose extension matches are included.
        Example: ['.py', '.gizmo', '.nk', '.json']
        Pass None (default) to include everything.

    Returns
    -------
    str
        Path to the created .zip file.

    Raises
    ------
    ValueError
        If folder_path does not exist or is not a directory.
    """
    folder_path = os.path.abspath(folder_path)
    if not os.path.isdir(folder_path):
        raise ValueError(f"Not a directory: {folder_path}")

    if output_zip is None:
        output_zip = folder_path.rstrip(os.sep) + '.zip'

    if include_extensions:
        include_extensions = {e.lower() if e.startswith('.') else f'.{e.lower()}'
                              for e in include_extensions}

    file_count = 0
    with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(folder_path):
            # Skip hidden dirs and Python cache
            dirs[:] = sorted(
                d for d in dirs
                if not d.startswith('.') and d not in ('__pycache__', '.git')
            )
            for filename in files:
                if filename.startswith('.'):
                    continue
                if include_extensions:
                    ext = os.path.splitext(filename)[1].lower()
                    if ext not in include_extensions:
                        continue

                abs_path = os.path.join(root, filename)
                arc_name = os.path.relpath(abs_path, os.path.dirname(folder_path))
                zf.write(abs_path, arc_name)
                file_count += 1

    size_kb = os.path.getsize(output_zip) / 1024
    print(f"[zip_folder] {file_count} files → {output_zip}  ({size_kb:.1f} KB)")
    return output_zip


def list_zip_contents(zip_path):
    """
    Return metadata for every entry in a .zip file.

    Returns
    -------
    list[dict]
        Each dict has keys: name, size, compress, date.
    """
    entries = []
    with zipfile.ZipFile(zip_path, 'r') as zf:
        for info in zf.infolist():
            entries.append({
                'name':     info.filename,
                'size':     info.file_size,
                'compress': info.compress_size,
                'date':     datetime(*info.date_time).strftime('%Y-%m-%d %H:%M'),
            })
    return entries


# ── Public: Install ────────────────────────────────────────────────────────────

def install_from_zip(zip_path, install_dir=None, overwrite=True, progress_cb=None):
    """
    Extract a tools .zip and record it in the manifest.

    Parameters
    ----------
    zip_path : str
        Path to the .zip file to install.
    install_dir : str | None
        Where to extract. Defaults to ~/.nuke/tools/<stem>/
    overwrite : bool
        If False, skip files that already exist.
    progress_cb : callable | None
        Optional callback(current, total) for progress reporting.

    Returns
    -------
    str
        Path to the directory where files were installed.
    """
    zip_path = os.path.abspath(zip_path)
    if not os.path.isfile(zip_path):
        raise FileNotFoundError(f"Zip not found: {zip_path}")

    stem = os.path.splitext(os.path.basename(zip_path))[0]

    if install_dir is None:
        install_dir = os.path.join(TOOLS_DIR, stem)

    _ensure_dir(install_dir)

    extracted = []
    skipped   = []

    with zipfile.ZipFile(zip_path, 'r') as zf:
        members = zf.infolist()
        total   = len(members)

        for idx, member in enumerate(members, 1):
            if progress_cb:
                progress_cb(idx, total)

            # Strip the top-level folder name so files land directly in install_dir
            parts = member.filename.split('/', 1)
            rel   = parts[1] if len(parts) > 1 else parts[0]
            if not rel:
                continue

            dest = os.path.join(install_dir, rel)

            # Directory entry
            is_dir = member.filename.endswith('/')
            if is_dir:
                os.makedirs(dest, exist_ok=True)
                continue

            os.makedirs(os.path.dirname(dest), exist_ok=True)

            if not overwrite and os.path.exists(dest):
                skipped.append(rel)
                continue

            with zf.open(member) as src, open(dest, 'wb') as dst:
                shutil.copyfileobj(src, dst)
            extracted.append(rel)

    # Record in manifest
    manifest = _load_manifest()
    manifest[stem] = {
        'install_dir':  install_dir,
        'zip_source':   zip_path,
        'installed_at': datetime.now().isoformat(),
        'file_count':   len(extracted),
        'files':        extracted,
    }
    _save_manifest(manifest)

    print(f"[install] '{stem}' → {install_dir}  "
          f"({len(extracted)} extracted, {len(skipped)} skipped)")
    return install_dir


def install_from_folder(folder_path, install_dir=None, overwrite=True,
                        progress_cb=None):
    """
    Copy a tools folder directly into the tools directory and record it in the
    manifest.  No zip file required.

    Parameters
    ----------
    folder_path : str
        Source directory containing the tool files.
    install_dir : str | None
        Destination directory.  Defaults to ~/.nuke/tools/<folder_name>/
    overwrite : bool
        If False, skip files that already exist at the destination.
    progress_cb : callable | None
        Optional callback(current_file_index, total_files) for UI progress.

    Returns
    -------
    str
        Absolute path to the install directory.

    Raises
    ------
    ValueError
        If folder_path does not exist or is not a directory.
    """
    folder_path = os.path.abspath(folder_path)
    if not os.path.isdir(folder_path):
        raise ValueError(f"Not a directory: {folder_path}")

    name = os.path.basename(folder_path.rstrip(os.sep))

    if install_dir is None:
        install_dir = os.path.join(TOOLS_DIR, name)

    _ensure_dir(install_dir)

    # Collect all files first so we can report accurate progress
    all_files = []
    for root, dirs, files in os.walk(folder_path):
        dirs[:] = sorted(
            d for d in dirs
            if not d.startswith('.') and d not in ('__pycache__', '.git')
        )
        for fn in files:
            if not fn.startswith('.') and fn.lower() != 'manifest.json':
                all_files.append(os.path.join(root, fn))

    total     = len(all_files)
    copied    = []
    skipped   = []

    for idx, src_abs in enumerate(all_files, 1):
        if progress_cb:
            progress_cb(idx, total)

        rel  = os.path.relpath(src_abs, folder_path)
        dest = os.path.join(install_dir, rel)

        os.makedirs(os.path.dirname(dest), exist_ok=True)

        if not overwrite and os.path.exists(dest):
            skipped.append(rel)
            continue

        shutil.copy2(src_abs, dest)
        copied.append(rel)

    # Record in manifest
    manifest = _load_manifest()
    manifest[name] = {
        'install_dir':   install_dir,
        'source_folder': folder_path,
        'installed_at':  datetime.now().isoformat(),
        'file_count':    len(copied),
        'files':         copied,
        'method':        'folder',
    }
    _save_manifest(manifest)

    print(f"[install_folder] '{name}' → {install_dir}  "
          f"({len(copied)} copied, {len(skipped)} skipped)")
    return install_dir


def uninstall_tool(tool_name):
    """
    Remove an installed tool by its manifest key.

    Parameters
    ----------
    tool_name : str
        Key as it appears in the manifest (usually the zip stem).

    Returns
    -------
    bool
        True if the tool was found and removed, False otherwise.
    """
    manifest = _load_manifest()
    if tool_name not in manifest:
        print(f"[uninstall] '{tool_name}' not found in manifest.")
        return False

    info = manifest.pop(tool_name)
    install_dir = info.get('install_dir', '')

    if os.path.isdir(install_dir):
        shutil.rmtree(install_dir)
        print(f"[uninstall] Removed: {install_dir}")
    else:
        print(f"[uninstall] Directory already gone: {install_dir}")

    _save_manifest(manifest)
    print(f"[uninstall] '{tool_name}' removed from manifest.")
    return True


def get_installed_tools():
    """Return the full manifest dict."""
    return _load_manifest()


# ── Public: Path Registration ──────────────────────────────────────────────────

def register_tool_path(path):
    """
    Add *path* to sys.path and to Nuke's plugin search path.
    Safe to call outside Nuke (Nuke part is silently skipped).
    """
    if not os.path.isdir(path):
        print(f"[register] Skipped (not a directory): {path}")
        return

    if path not in sys.path:
        sys.path.insert(0, path)

    try:
        import nuke
        nuke.pluginAddPath(path)
    except ImportError:
        pass  # Outside Nuke

    print(f"[register] {path}")


def register_nuke_plugin_path(path, target_nuke_version, major_only=True):
    """
    Persistently write a nuke.pluginAddPath() call into ~/.nuke/init.py,
    scoped to the given Nuke major version (or globally if major_only=False).

    Behaviour
    ---------
    • If the path is already present in init.py  → does nothing (idempotent).
    • If a version block for that major already exists → appends the new line
      inside the existing block.
    • Otherwise → appends a brand-new block with a labelled header.

    Parameters
    ----------
    path : str
        The directory path to register (backslashes are normalised to forward
        slashes so the line is cross-platform).
    target_nuke_version : str
        Full version string, e.g. "14.0v1" or "15.1".  Only the major part
        (before the first ".") is used when major_only=True.
    major_only : bool
        True  → wrap the line in  ``if nuke.NUKE_VERSION_MAJOR == <major>:``
        False → write the line at module level (registers for every Nuke).

    Example init.py output (major_only=True, version "14.0v1")
    -----------------------------------------------------------
    ::

        # ======== PipelineCore_nuke_installer | Nuke 14.0v1 | Author: Nitin Kashyap ======== VFX Compositor ======== #
        if nuke.NUKE_VERSION_MAJOR == 14:
            nuke.pluginAddPath(r"/path/to/tools")

    Returns
    -------
    None
    """
    init_file = Path(os.path.expanduser("~/.nuke/init.py"))
    init_file.parent.mkdir(parents=True, exist_ok=True)

    major = target_nuke_version.split(".")[0]
    path  = path.replace("\\", "/")

    header = (
        f"# ======== NK Tools Manager | Nuke {target_nuke_version} "
        f"| Author: Nitin Kashyap ======== VFX Compositor ======== #"
    )

    if major_only:
        block_start = f"if nuke.NUKE_VERSION_MAJOR == {major}:"
        indent      = "    "
    else:
        block_start = None
        indent      = ""

    new_line = f'{indent}nuke.pluginAddPath(r"{path}")'

    # Read existing content (or start fresh)
    text  = init_file.read_text(encoding="utf-8") if init_file.exists() else ""

    # ── CASE 1: path already registered ──────────────────────────────────────
    if path in text:
        print(f"[register_init] Already registered: {path}")
        return

    lines = text.splitlines()

    # ── CASE 2: version block already exists → insert inside it ──────────────
    if major_only and block_start in lines:
        idx = lines.index(block_start) + 1
        # advance past existing indented lines belonging to this block
        while idx < len(lines) and lines[idx].startswith(indent):
            idx += 1
        lines.insert(idx, new_line)
        init_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"[register_init] Appended to existing block (Nuke {major}): {path}")
        return

    # ── CASE 3: create a new block at the end of the file ────────────────────
    block = ["", header]
    if major_only:
        block.append(block_start)
    block.append(new_line)
    block.append("")

    init_file.write_text(text + "\n".join(block) + "\n", encoding="utf-8")
    label = f"version {major} block" if major_only else "global"
    print(f"[register_init] New {label} written to init.py: {path}")


def register_all_installed():
    """Register every installed tool directory with Nuke."""
    tools = get_installed_tools()
    if not tools:
        print("[register_all] No installed tools found.")
        return
    for name, info in tools.items():
        d = info.get('install_dir', '')
        if d:
            register_tool_path(d)
    print(f"[register_all] {len(tools)} tool(s) registered.")
