# init.py  —  place this in  ~/.nuke/init.py
"""
Nuke startup script.
Automatically registers all installed tools with Nuke's plugin search path.

Place this file (or merge its contents) into:
    ~/.nuke/init.py
"""

import sys
import os

# ── Locate the tools directory relative to this file ──────────────────────────
_NUKE_DIR   = os.path.dirname(os.path.abspath(__file__))
_TOOLS_ROOT = os.path.join(_NUKE_DIR, 'tools')

# ── Add tools root to sys.path so zip_utils.py is importable ─────────────────
if _TOOLS_ROOT not in sys.path:
    sys.path.insert(0, _TOOLS_ROOT)

# ── Auto-register all installed sub-tools ────────────────────────────────────
try:
    from zip_utils import register_all_installed
    register_all_installed()
    print("[NukeTools] init.py: all installed tools registered.")
except Exception as _e:
    print(f"[NukeTools] init.py warning: {_e}")
