# ══════════════════════════════════════════════════════════════════════════════
# sound_utils.py  —  NK Tools Manager  |  Multi-WAV Sound Utility
# Author : Nitin Kashyap  |  Junior VFX Compositor
#
# Provides:
#   SOUNDS          — list of discovered .wav paths  (from sounds/ subfolder)
#   play_async()    — play the chosen sound, non-blocking
#   show_picker()   — open the "Choose Sound" dialog
# ══════════════════════════════════════════════════════════════════════════════

import os
import threading

# ── Locate the sounds/ directory next to this file ───────────────────────────
_BASE_DIR   = os.path.dirname(os.path.abspath(__file__))
_SOUNDS_DIR = os.path.join(_BASE_DIR, "sounds")
_CFG_FILE   = os.path.join(_BASE_DIR, "setting_tip", "chosen_sound.cfg")

# ── Discover all .wav files ───────────────────────────────────────────────────
def _scan_wavs():
    """Return sorted list of .wav paths inside the sounds/ folder."""
    wavs = []
    if os.path.isdir(_SOUNDS_DIR):
        for name in sorted(os.listdir(_SOUNDS_DIR)):
            if name.lower().endswith(".wav"):
                wavs.append(os.path.join(_SOUNDS_DIR, name))
    return wavs

SOUNDS = _scan_wavs()   # module-level list — importable


# ── Persistent chosen sound ───────────────────────────────────────────────────
def get_chosen():
    """Return the currently chosen .wav path, or first found, or None."""
    if os.path.isfile(_CFG_FILE):
        try:
            with open(_CFG_FILE, "r", encoding="utf-8") as fh:
                p = fh.read().strip()
            if p == "__none__":
                return None
            if os.path.isfile(p):
                return p
        except Exception:
            pass
    return SOUNDS[0] if SOUNDS else None


def set_chosen(path):
    """Save chosen .wav path (or '__none__') to config file."""
    try:
        with open(_CFG_FILE, "w", encoding="utf-8") as fh:
            fh.write(path or "__none__")
    except Exception:
        pass


# ── Non-blocking playback ─────────────────────────────────────────────────────
def _play_in_thread(wav_path):
    """Internal: play wav_path in a daemon thread."""
    def _worker():
        try:                                     # Windows
            import winsound
            winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            return
        except ImportError:
            pass
        try:                                     # macOS
            import subprocess
            subprocess.Popen(["afplay", wav_path],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
            return
        except Exception:
            pass
        try:                                     # Linux
            import subprocess
            subprocess.Popen(["aplay", wav_path],
                             stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
        except Exception:
            pass
    threading.Thread(target=_worker, daemon=True).start()


def play_async(wav_path=None):
    """
    Play a sound asynchronously.
    If wav_path is None, plays the user's chosen sound.
    """
    path = wav_path or get_chosen()
    if path and os.path.isfile(path):
        _play_in_thread(path)


# ══════════════════════════════════════════════════════════════════════════════
# CHOOSE SOUND DIALOG
# ══════════════════════════════════════════════════════════════════════════════

def show_picker(parent=None):
    """
    Open the Choose Sound dialog.
    Lists all .wav files found in  sounds/  plus a 'No sound' option.
    Includes a ▶ Preview button.  Choice is saved to  chosen_sound.cfg.
    """
    try:
        from PySide6 import QtWidgets, QtCore, QtGui
        from PySide6.QtCore import Qt
    except ImportError:
        from PySide2 import QtWidgets, QtCore, QtGui
        from PySide2.QtCore import Qt

    # Refresh the wav list in case files were added since startup
    global SOUNDS
    SOUNDS = _scan_wavs()

    dlg = QtWidgets.QDialog(parent)
    dlg.setWindowTitle("Choose Install Sound")
    dlg.setFixedSize(520, 400)
    dlg.setStyleSheet("""
        QDialog {
            background: #1e1e1e;
            color: #d0d0d0;
        }
        QLabel {
            color: #aaa;
            font-size: 12px;
        }
        QLabel#header {
            color: #f0a500;
            font-size: 13px;
            font-weight: bold;
        }
        QListWidget {
            background: #141414;
            border: 1px solid #333;
            border-radius: 4px;
            color: #d0d0d0;
            font-size: 12px;
            outline: none;
        }
        QListWidget::item {
            padding: 7px 12px;
            border-bottom: 1px solid #1e1e1e;
        }
        QListWidget::item:selected {
            background: #004a55;
            color: #00BCD4;
            border-left: 3px solid #00BCD4;
        }
        QListWidget::item:hover {
            background: #252525;
        }
        QPushButton {
            background: #2a2a2a;
            border: 1px solid #444;
            border-radius: 4px;
            padding: 6px 16px;
            color: #d0d0d0;
            min-height: 28px;
            font-size: 12px;
        }
        QPushButton:hover  { border-color: #00BCD4; color: #fff; }
        QPushButton#preview {
            background: #003040;
            border-color: #006070;
            color: #00BCD4;
            min-width: 90px;
        }
        QPushButton#preview:hover { background: #004555; }
        QPushButton#save {
            background: #004050;
            border-color: #00BCD4;
            color: #00BCD4;
            font-weight: bold;
            min-width: 120px;
        }
        QPushButton#save:hover { background: #006070; }
        QPushButton#no_sound {
            background: #2a1515;
            border-color: #883333;
            color: #ff8080;
        }
        QPushButton#no_sound:hover { background: #3a1e1e; }
        QLabel#folder_lbl {
            color: #444;
            font-size: 10px;
        }
    """)

    layout = QtWidgets.QVBoxLayout(dlg)
    layout.setContentsMargins(18, 16, 18, 16)
    layout.setSpacing(10)

    # Header
    hdr = QtWidgets.QLabel("Install Complete Sound")
    hdr.setObjectName("header")
    layout.addWidget(hdr)

    desc = QtWidgets.QLabel(
        "Select the sound that plays when installation finishes.\n"
        "Add more .wav files to the  sounds/  folder to see them here."
    )
    desc.setWordWrap(True)
    layout.addWidget(desc)

    # List
    lst = QtWidgets.QListWidget()
    lst.setAlternatingRowColors(False)

    current = get_chosen()

    # "No sound" entry
    no_item = QtWidgets.QListWidgetItem("No sound")
    no_item.setData(Qt.UserRole, "__none__")
    lst.addItem(no_item)
    if current is None:
        lst.setCurrentItem(no_item)

    for wav in SOUNDS:
        label = os.path.splitext(os.path.basename(wav))[0]
        item  = QtWidgets.QListWidgetItem("    🎵   " + label)
        item.setData(Qt.UserRole, wav)
        lst.addItem(item)
        if wav == current:
            lst.setCurrentItem(item)

    if lst.currentItem() is None and lst.count() > 0:
        lst.setCurrentRow(0)

    layout.addWidget(lst, 1)

    # Folder info
    folder_lbl = QtWidgets.QLabel("Sounds folder:  " + _SOUNDS_DIR)
    folder_lbl.setObjectName("folder_lbl")
    folder_lbl.setWordWrap(True)
    layout.addWidget(folder_lbl)

    # Button row
    btn_row = QtWidgets.QHBoxLayout()
    btn_row.setSpacing(8)

    preview_btn = QtWidgets.QPushButton("▶  Preview")
    preview_btn.setObjectName("preview")
    preview_btn.setToolTip("Preview the selected sound")

    def _preview():
        sel = lst.currentItem()
        if sel:
            p = sel.data(Qt.UserRole)
            if p and p != "__none__":
                play_async(p)

    preview_btn.clicked.connect(_preview)
    btn_row.addWidget(preview_btn)

    btn_row.addStretch()

    no_btn = QtWidgets.QPushButton("No Sound")
    no_btn.setObjectName("no_sound")
    no_btn.setToolTip("Disable install sound")

    def _pick_none():
        for i in range(lst.count()):
            if lst.item(i).data(Qt.UserRole) == "__none__":
                lst.setCurrentRow(i)
                break

    no_btn.clicked.connect(_pick_none)
    btn_row.addWidget(no_btn)

    cancel_btn = QtWidgets.QPushButton("Cancel")
    cancel_btn.clicked.connect(dlg.reject)
    btn_row.addWidget(cancel_btn)

    save_btn = QtWidgets.QPushButton("Save Choice")
    save_btn.setObjectName("save")
    save_btn.setToolTip("Save and use this sound")

    def _save():
        sel = lst.currentItem()
        if sel:
            set_chosen(sel.data(Qt.UserRole))
        dlg.accept()

    save_btn.clicked.connect(_save)
    btn_row.addWidget(save_btn)

    layout.addLayout(btn_row)

    try:
        dlg.exec()
    except Exception:
        dlg.exec_()
