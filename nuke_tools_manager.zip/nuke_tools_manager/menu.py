# ══════════════════════════════════════════════════════════════════════════════
# NK Tools Manager — Nuke Menu & Toolbar Launcher
# Author : Nitin Kashyap  |  Junior VFX Compositor
#
# INSTALL:  Drop into  ~/.nuke/menu.py
#            Auto-detects nuke_tools_manager folder anywhere in ~/.nuke
#            Auto-detects all icons & splash image inside that folder
#            No manual path editing needed
# ══════════════════════════════════════════════════════════════════════════════


__title__ = 'NK Tools Manager'
__version__ = "1.0.0"
__author__ = "Nitin Kashyap"
__release_date__ = 'june, 9 2026'
__license__ = 'MIT'



import nuke
import os
import sys
import datetime


version= "v1.0.0"
update_date= "9 june 2026"


# ══════════════════════════════════════════════════════════════════════════════
#              CUSTOMIZE SPLASH — edit these, nothing else needed
# ══════════════════════════════════════════════════════════════════════════════

SPLASH_WIDTH   = 880
SPLASH_HEIGHT  = 336
STEP_DELAY_MS  = 320

SPLASH_STEPS = [
    (15,  "Initialising…"),
    (35,  "Loading modules…"),
    (60,  "Building UI…"),
    (80,  "Registering paths…"),
    (100, "Ready!"),
]

COLOR_BAR_BG    = "#111111"
COLOR_BAR_START = "#006070"
COLOR_BAR_END   = "#00BCD4"
COLOR_STATUS    = "#00BCD4"
FONT_STATUS_PX  = 11


# ══════════════════════════════════════════════════════════════════════════════
# AUTO-DETECT  ①  Find the nuke_tools_manager folder
# Scans ~/.nuke depth-1 and depth-2 for any folder with tool_manager_ui.py
# ══════════════════════════════════════════════════════════════════════════════

def _find_tools_dir():
    """
    Returns the folder that contains tool_manager_ui.py, searching inside
    C:/Users/<user>/.nuke  at depth 1 then depth 2.
    Prints the detected path to Nuke's Script Editor output.
    """
    nuke_home = os.path.expanduser("~/.nuke")
    if not os.path.isdir(nuke_home):
        return None

    # depth 1 — ~/.nuke/<folder>/tool_manager_ui.py
    try:
        for entry in sorted(os.scandir(nuke_home), key=lambda e: e.name):
            if not entry.is_dir():
                continue
            if os.path.isfile(os.path.join(entry.path, "tool_manager_ui.py")):
                return entry.path
    except Exception:
        pass

    # depth 2 — ~/.nuke/<parent>/<folder>/tool_manager_ui.py
    try:
        for parent in sorted(os.scandir(nuke_home), key=lambda e: e.name):
            if not parent.is_dir():
                continue
            for child in sorted(os.scandir(parent.path), key=lambda e: e.name):
                if not child.is_dir():
                    continue
                if os.path.isfile(os.path.join(child.path, "tool_manager_ui.py")):
                    return child.path
    except Exception:
        pass

    return None


# ══════════════════════════════════════════════════════════════════════════════
# AUTO-DETECT  ②  Find icons & splash inside the detected folder
# Looks in root of folder  AND  in an icons/ subfolder
# ══════════════════════════════════════════════════════════════════════════════

def _find_asset(base_dir, *filenames):
    """
    Search for filenames in:
      base_dir/
      base_dir/logo/
      base_dir/icons/
      base_dir/images/
    Returns the first match, or None.
    """
    search_dirs = [
        base_dir,
        os.path.join(base_dir, "logo"),
        os.path.join(base_dir, "icons"),
        os.path.join(base_dir, "images"),
    ]
    for d in search_dirs:
        for name in filenames:
            p = os.path.join(d, name)
            if os.path.isfile(p):
                return p
    return None


# ── Run detection ─────────────────────────────────────────────────────────────
# Pre-declare all module-level vars so they're always in scope
_DIR         = None
_SPLASH      = None
_ICO_256 = _ICO_128 = _ICO_64 = _ICO_48 = _ICO_32 = _ICO_16 = None
_MENU_ICO    = None
_TOOLBAR_ICO = None
_SOUNDS_DIR  = None
_WAV_FILES   = []
_SOUND_CFG   = None

def _load_chosen_sound():
    if _SOUND_CFG and os.path.isfile(_SOUND_CFG):
        try:
            with open(_SOUND_CFG, "r") as _fh:
                _p = _fh.read().strip()
            if _p and os.path.isfile(_p):
                return _p
        except Exception:
            pass
    return _WAV_FILES[0] if _WAV_FILES else None

def _save_chosen_sound(_path):
    if not _SOUND_CFG:
        return
    try:
        with open(_SOUND_CFG, "w") as _fh:
            _fh.write(_path)
    except Exception:
        pass

_DIR = _find_tools_dir()

if _DIR:
    # nuke.tprint(
    #     "\n"
    #     "╔══════════════════════════════════════════════════════╗\n"
    #     "║        NK Tools Manager — Auto-detected              ║\n"
    #     "║  Path : {:<44}║\n"
    #     "╚══════════════════════════════════════════════════════╝".format(
    #         (_DIR[:42] + "..") if len(_DIR) > 44 else _DIR + " " * (44 - len(_DIR))
    #     )
    # )
    # if _DIR not in sys.path:
    #     sys.path.insert(0, _DIR)

    # ── Auto-detect every asset ───────────────────────────────────────────────
    _SPLASH      = _find_asset(_DIR, "splash_screen.png", "splash.png")
    _ICO_256     = _find_asset(_DIR, "icon_256.png", "logo_256.png")
    _ICO_128     = _find_asset(_DIR, "icon_128.png", "logo_128.png")
    _ICO_64      = _find_asset(_DIR, "icon_64.png",  "logo_64.png")
    _ICO_48      = _find_asset(_DIR, "icon_48.png",  "logo_48.png")
    _ICO_32      = _find_asset(_DIR, "icon_32.png",  "logo_32.png")
    _ICO_16      = _find_asset(_DIR, "icon_16.png",  "logo_16.png")
    _MENU_ICO    = _ICO_32  or _ICO_48  or _ICO_64  or _ICO_256
    _TOOLBAR_ICO = _ICO_256 or _ICO_128 or _ICO_64  or _ICO_32

    # ── Auto-detect WAV files in sounds/ subfolder ────────────────────────────
    _SOUNDS_DIR = os.path.join(_DIR, "sounds")
    _SOUND_CFG  = os.path.join(_DIR, "setting_tip", "splash_sound.cfg")
    if os.path.isdir(_SOUNDS_DIR):
        for _f in sorted(os.listdir(_SOUNDS_DIR)):
            if _f.lower().endswith(".wav"):
                _WAV_FILES.append(os.path.join(_SOUNDS_DIR, _f))

    # nuke.tprint("  splash   : {}".format(_SPLASH      or "NOT FOUND"))
    # nuke.tprint("  icon_256 : {}".format(_ICO_256     or "NOT FOUND"))
    # nuke.tprint("  icon_32  : {}".format(_ICO_32      or "NOT FOUND"))
    # nuke.tprint("  sounds   : {} WAV file(s) in sounds/".format(len(_WAV_FILES)))

else:
    nuke.warning(
        "NK Tools Manager: tool_manager_ui.py not found inside ~/.nuke\n"
        "Place the nuke_tools_manager folder at:\n"
        "{}".format(os.path.join(os.path.expanduser("~"), ".nuke", "nuke_tools_manager"))
    )



# ══════════════════════════════════════════════════════════════════════════════
# SOUND — play WAV in background thread, non-blocking
# ══════════════════════════════════════════════════════════════════════════════

def _play_wav(wav_path):
    """Play a WAV file non-blocking. Works on Windows, macOS, Linux."""
    if not wav_path or not os.path.isfile(wav_path):
        return
    import threading
    def _worker():
        try:
            # Windows — winsound (no extra deps)
            import winsound
            winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            return
        except ImportError:
            pass
        try:
            # macOS
            import subprocess
            subprocess.Popen(["afplay", wav_path],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        except Exception:
            pass
        try:
            # Linux (aplay)
            import subprocess
            subprocess.Popen(["aplay", wav_path],
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            pass
    threading.Thread(target=_worker, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════════
# SOUND PICKER DIALOG
# ══════════════════════════════════════════════════════════════════════════════

def _show_sound_picker():
    """Open a dialog to choose which WAV plays during the splash screen."""
    try:
        from PySide6 import QtWidgets, QtCore, QtGui
        from PySide6.QtCore import Qt
    except ImportError:
        from PySide2 import QtWidgets, QtCore, QtGui
        from PySide2.QtCore import Qt

    if not _WAV_FILES:
        nuke.message(
            "No WAV files found.\n\n"
            "Add .wav files to:\n"
            "{}".format(_SOUNDS_DIR if _DIR else "~/.nuke/nuke_tools_manager/sounds/")
        )
        return

    app = QtWidgets.QApplication.instance()

    dlg = QtWidgets.QDialog(None, Qt.Tool | Qt.WindowStaysOnTopHint)
    dlg.setWindowTitle("NK Tools — Choose Splash Sound")
    dlg.setFixedSize(500, 380)
    dlg.setStyleSheet("""
        QDialog      { background: #1e1e1e; color: #d0d0d0; }
        QLabel       { color: #aaa; font-size: 12px; }
        QListWidget  {
            background: #141414; border: 1px solid #333;
            border-radius: 4px; color: #d0d0d0; font-size: 12px;
        }
        QListWidget::item          { padding: 6px 10px; }
        QListWidget::item:selected { background: #005f6b; color: #fff; }
        QListWidget::item:hover    { background: #252525; }
        QPushButton {
            background: #2a2a2a; border: 1px solid #444;
            border-radius: 4px; padding: 6px 18px;
            color: #d0d0d0; min-height: 28px; font-size: 12px;
        }
        QPushButton:hover   { border-color: #00BCD4; color: #fff; }
        QPushButton#preview { background: #003040; border-color: #006070; color: #00BCD4; }
        QPushButton#preview:hover { background: #004050; }
        QPushButton#save    { background: #004050; border-color: #00BCD4; color: #00BCD4; font-weight: bold; }
        QPushButton#save:hover { background: #006070; }
        QPushButton#none    { background: #2a1010; border-color: #803030; color: #ff8080; }
        QPushButton#none:hover { background: #3a1a1a; }
    """)

    layout = QtWidgets.QVBoxLayout(dlg)
    layout.setContentsMargins(18, 16, 18, 16)
    layout.setSpacing(10)

    lbl = QtWidgets.QLabel("Select a sound to play when the splash screen opens:")
    lbl.setWordWrap(True)
    layout.addWidget(lbl)

    lst = QtWidgets.QListWidget()
    lst.setAlternatingRowColors(True)

    current = _load_chosen_sound()

    # "No sound" option
    no_snd = QtWidgets.QListWidgetItem("No sound")
    no_snd.setData(Qt.UserRole, "__none__")
    lst.addItem(no_snd)

    for wav in _WAV_FILES:
        name = os.path.splitext(os.path.basename(wav))[0]
        item = QtWidgets.QListWidgetItem("" + name)
        item.setData(Qt.UserRole, wav)
        lst.addItem(item)
        if wav == current:
            lst.setCurrentItem(item)

    if current is None and lst.count() > 0:
        lst.setCurrentRow(0)

    layout.addWidget(lst, 1)

    # Buttons row
    btn_row = QtWidgets.QHBoxLayout()

    preview_btn = QtWidgets.QPushButton("▶  Preview")
    preview_btn.setObjectName("preview")
    def _preview():
        sel = lst.currentItem()
        if sel:
            p = sel.data(Qt.UserRole)
            if p != "__none__":
                _play_wav(p)
    preview_btn.clicked.connect(_preview)
    btn_row.addWidget(preview_btn)

    btn_row.addStretch()

    none_btn = QtWidgets.QPushButton("No Sound")
    none_btn.setObjectName("none")
    def _set_none():
        for i in range(lst.count()):
            if lst.item(i).data(Qt.UserRole) == "__none__":
                lst.setCurrentRow(i)
                break
    none_btn.clicked.connect(_set_none)
    btn_row.addWidget(none_btn)

    cancel_btn = QtWidgets.QPushButton("Cancel")
    cancel_btn.clicked.connect(dlg.reject)
    btn_row.addWidget(cancel_btn)

    save_btn = QtWidgets.QPushButton("Save Choice")
    save_btn.setStyleSheet("QPushButton { font-size: 10px; color white; }")
    save_btn.setObjectName("save")
    def _save():
        sel = lst.currentItem()
        if sel:
            p = sel.data(Qt.UserRole)
            if p == "__none__":
                _save_chosen_sound("")
            else:
                _save_chosen_sound(p)
        dlg.accept()
    save_btn.clicked.connect(_save)
    btn_row.addWidget(save_btn)

    layout.addLayout(btn_row)

    # Info label
    info = QtWidgets.QLabel("WAV folder:  " + (_SOUNDS_DIR if _DIR else "not detected"))
    info.setStyleSheet("font-size:10px; color:#555;")
    layout.addWidget(info)

    dlg.exec_() if hasattr(dlg, 'exec_') else dlg.exec()

# ══════════════════════════════════════════════════════════════════════════════
# SPLASH SCREEN  — splash_screen.png as full background
# ══════════════════════════════════════════════════════════════════════════════

def _show_splash_then_launch():
    try:
        from PySide6 import QtWidgets, QtCore, QtGui
        from PySide6.QtCore import Qt
    except ImportError:
        from PySide2 import QtWidgets, QtCore, QtGui
        from PySide2.QtCore import Qt

    app = QtWidgets.QApplication.instance()

    splash = QtWidgets.QWidget(
        None, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool
    )
    splash.setFixedSize(SPLASH_WIDTH, SPLASH_HEIGHT)
    splash.setAttribute(Qt.WA_TranslucentBackground)

    geo = app.primaryScreen().geometry()
    splash.move(
        geo.center().x() - SPLASH_WIDTH  // 2,
        geo.center().y() - SPLASH_HEIGHT // 2,
    )

    # ── Background ────────────────────────────────────────────────────────────
    bg = QtWidgets.QLabel(splash)
    bg.setGeometry(0, 0, SPLASH_WIDTH, SPLASH_HEIGHT)
    if _SPLASH and os.path.isfile(_SPLASH):
        pix = QtGui.QPixmap(_SPLASH).scaled(
            SPLASH_WIDTH, SPLASH_HEIGHT,
            Qt.IgnoreAspectRatio, Qt.SmoothTransformation,
        )
        bg.setPixmap(pix)
    else:
        # Fallback card if splash image missing
        bg.setStyleSheet("""
            background: qlineargradient(x1:0,y1:0,x2:1,y2:1,
                stop:0 #0d1117, stop:1 #0f3460);
            border-radius: 12px;
            border: 2px solid #00BCD4;
        """)
        # Fallback logo text
        fallback = QtWidgets.QLabel("NK", splash)
        fallback.setGeometry(0, 0, SPLASH_WIDTH, SPLASH_HEIGHT - 60)
        fallback.setAlignment(Qt.AlignCenter)
        fallback.setStyleSheet(
            "font-size:80px; font-weight:bold; color:#00BCD4; background:transparent;"
        )

    # ── CRAGL-style overlay text ──────────────────────────────────────────────
    # Common style helpers
    _TRANS = "background: transparent;"
    _CYAN  = COLOR_STATUS          # e.g. "#00BCD4"
    _DIM   = "rgba(0,180,200,140)" # dimmer cyan
    _GREY  = "rgba(150,160,170,160)"

    # ── TOP-LEFT: "connect" + "v1.0.0" ───────────────────────────────────────
    connect_lbl = QtWidgets.QLabel("connect", splash)
    connect_lbl.setGeometry(28, 20, 200, 22)
    connect_lbl.setStyleSheet(
        "font-size:18px; font-family:'Segoe UI',Arial; "
        "color:{}; letter-spacing:2px; {};".format(_CYAN, _TRANS)
    )

    version_lbl = QtWidgets.QLabel("v1.0.0", splash)
    version_lbl.setGeometry(28, 40, 200, 16)
    version_lbl.setStyleSheet(
        "font-size:12px; font-family:'Segoe UI',Arial; "
        "color:{}; {};".format(_DIM, _TRANS)
    )

    # ── BOTTOM separator line ─────────────────────────────────────────────────
    sep_y = SPLASH_HEIGHT - 52
    sep   = QtWidgets.QFrame(splash)
    sep.setGeometry(0, sep_y, SPLASH_WIDTH, 1)
    sep.setStyleSheet("background: transparent; border: none;")


    # ── BOTTOM-LEFT: NK Tools Manager info ────────────────────────────────────
    bl_lbl = QtWidgets.QLabel(
        "connect v1.0.0\n(c) 2026 NK Tools Manager \nNitin Kashyap",
        splash
    )
    bl_lbl.setGeometry(18, sep_y + -10, 340, 46)
    bl_lbl.setStyleSheet(
        "font-size:10px; font-family:'Segoe UI',Arial; "
        "line-height:120%; color:{}; {};".format(_GREY, _TRANS)
    )

    # ── BOTTOM-RIGHT: "loading data..." (dynamic) ─────────────────────────────
    status = QtWidgets.QLabel("loading data...", splash)
    status.setGeometry(SPLASH_WIDTH - 220, sep_y + 14, 205, 18)
    status.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    status.setStyleSheet(
        "font-size:11px; font-family:'Segoe UI',Arial; "
        "color:{}; {};".format(_DIM, _TRANS)
    )

    # ── Progress bar (thin, flush bottom) ─────────────────────────────────────
    bar_y = SPLASH_HEIGHT - 5
    bar_w = SPLASH_WIDTH

    bar = QtWidgets.QProgressBar(splash)
    bar.setGeometry(0, bar_y, bar_w, 5)
    bar.setRange(0, 100)
    bar.setValue(0)
    bar.setTextVisible(False)
    bar.setStyleSheet("""
        QProgressBar {{
            background: rgba(0,0,0,80);
            border: none;
            border-radius: 0px;
        }}
        QProgressBar::chunk {{
            background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
                stop:0 {c0}, stop:1 {c1});
            border-radius: 0px;
        }}
    """.format(bg=COLOR_BAR_BG, c0=COLOR_BAR_START, c1=COLOR_BAR_END))

    splash.show()
    app.processEvents()

    # ── Play chosen splash sound ──────────────────────────────────────────────
    _play_wav(_load_chosen_sound())

    # ── Animate ───────────────────────────────────────────────────────────────
    _idx  = [0]
    timer = QtCore.QTimer()

    def _tick():
        if _idx[0] >= len(SPLASH_STEPS):
            timer.stop()
            splash.hide()
            splash.deleteLater()
            _open_tools()
            return
        val, msg = SPLASH_STEPS[_idx[0]]
        bar.setValue(val)
        status.setText(msg + "...")
        app.processEvents()
        _idx[0] += 1

    timer.timeout.connect(_tick)
    timer.start(STEP_DELAY_MS)


# ══════════════════════════════════════════════════════════════════════════════
# OPEN
# ══════════════════════════════════════════════════════════════════════════════

def _open_tools():
    if not _DIR:
        nuke.message(
            "NK Tools Manager not found.\n\n"
            "Expected location:\n"
            "{}".format(
                os.path.join(os.path.expanduser("~"), ".nuke", "nuke_tools_manager")
            )
        )
        return
    try:
        import tool_manager_ui
        tool_manager_ui.show()
    except Exception as e:
        nuke.message("NK Tools Manager — failed to open:\n\n{}".format(e))


def _launch():
    try:
        _show_splash_then_launch()
    except Exception as e:
        nuke.warning("NK splash failed ({}), opening directly.".format(e))
        _open_tools()


# ══════════════════════════════════════════════════════════════════════════════
# MENU BAR  →  Nuke > Tools > NK Tools Manager
# ══════════════════════════════════════════════════════════════════════════════
try:
    _m = nuke.menu("Nuke")
    _t = _m.findItem("NK Tools Manager") or _m.addMenu("NK Tools Manager")
    _t.addSeparator()
    _t.addCommand("NK Tools Manager",     _launch,             icon=_MENU_ICO or "")
    _t.addCommand("Choose Splash Sound…", _show_sound_picker,  icon=_MENU_ICO or "")
    _t.addSeparator()
except Exception as _e:
    nuke.warning("NK Tools Manager: menu failed — {}".format(_e))


# ══════════════════════════════════════════════════════════════════════════════
# TOOLBAR  →  Nodes > NK Tools > Open NK Tools Manager
# ══════════════════════════════════════════════════════════════════════════════
try:
    _tb = nuke.toolbar("Nodes").addMenu("NK Tools", icon=_TOOLBAR_ICO or "")
    _tb.addCommand("Open NK Tools Manager", _launch,            icon=_TOOLBAR_ICO or "")
    _tb.addCommand("Choose Splash Sound…",  _show_sound_picker, icon=_TOOLBAR_ICO or "")
except Exception as _e:
    nuke.warning("NK Tools Manager: toolbar failed — {}".format(_e))




license ="Copyright (C) 2026 by Nitin Kashyap. All Rights Reserved."
nuke.tprint(f"NK Tools Manager {version},  build  {update_date}. \n{license}")