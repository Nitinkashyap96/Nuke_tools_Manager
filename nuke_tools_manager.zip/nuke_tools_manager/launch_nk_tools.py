# ══════════════════════════════════════════════════════════════════════════════
# NK Tools Manager — Quick Launcher
# Can also be run from Nuke's Script Editor:
#   exec(open(r"~.nuke/NKToolsManager/launch_nk_tools.py").read())
# ══════════════════════════════════════════════════════════════════════════════

import os, sys

_DIR = os.path.dirname(os.path.abspath(__file__))
if _DIR not in sys.path:
    sys.path.insert(0, _DIR)

import tool_manager_ui
tool_manager_ui.show()
