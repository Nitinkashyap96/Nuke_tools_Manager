# pyside_compat.py
"""
Universal PySide2 / PySide6 compatibility shim for Nuke 13–16+
Import everything from here instead of directly from PySide2/PySide6.
"""
import sys

PYSIDE_VERSION = None
NUKE_VERSION = 0

# ── Detect Nuke version ────────────────────────────────────────────────────────
try:
    import nuke
    NUKE_VERSION = nuke.NUKE_VERSION_MAJOR
except ImportError:
    pass 

# ── Import Logic ──────────────────────────────────────────────────────────────
def _import_pyside(version):
    global QtWidgets, QtCore, QtGui, Signal, Slot, Qt, QThread, QObject, QTimer
    global QDesktopServices, QFont, QColor, QApplication, QGraphicsDropShadowEffect
    
    if version == 6:
        from PySide6 import QtWidgets, QtCore, QtGui
        from PySide6.QtCore import Signal, Slot, Qt, QThread, QObject, QTimer
        from PySide6.QtGui import QDesktopServices, QFont, QColor
        from PySide6.QtWidgets import QApplication, QGraphicsDropShadowEffect
    else:
        from PySide2 import QtWidgets, QtCore, QtGui
        from PySide2.QtCore import Signal, Slot, Qt, QThread, QObject, QTimer
        from PySide2.QtGui import QDesktopServices, QFont, QColor
        from PySide2.QtWidgets import QApplication, QGraphicsDropShadowEffect

# ── Try Versions in Order of Preference ──────────────────────────────────────
try:
    if NUKE_VERSION >= 15:
        _import_pyside(6)
        PYSIDE_VERSION = 6
    else:
        _import_pyside(2)
        PYSIDE_VERSION = 2
except ImportError:
    try:
        # Fallback to whatever is available
        alt_version = 2 if NUKE_VERSION >= 15 else 6
        _import_pyside(alt_version)
        PYSIDE_VERSION = alt_version
    except ImportError:
        raise ImportError(
            "Neither PySide2 nor PySide6 is available.\n"
            "Install with: pip install PySide2 or pip install PySide6"
        )

# ── Cross-version Helpers ─────────────────────────────────────────────────────

def exec_app(app_or_obj):
    """Handles app.exec() vs app.exec_()"""
    if hasattr(app_or_obj, 'exec'):
        return app_or_obj.exec()
    return app_or_obj.exec_()

# Helper for Enum compatibility (Qt6 is stricter)
# If a widget needs Alignment, use: Qt.AlignCenter (most are bridged in PySide6)

print(f"[NukeTools] PySide{PYSIDE_VERSION} loaded (Nuke {NUKE_VERSION})")