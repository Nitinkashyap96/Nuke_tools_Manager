# tool_manager_ui.py
"""
Nuke Tools Manager — Full PySide2 / PySide6 UI
================================================
Tabs
----
  1. Install     — browse a .zip, preview contents, install
  2. Zip/Export  — select a folder, choose filters, create .zip
  3. Installed   — browse, open, and uninstall tools
  4. Nuke Utils  — node finder, batch ops, knob setter, script info

Usage (from Nuke Script Editor)
--------------------------------
  import sys
  sys.path.insert(0, '/path/to/nuke_tools_manager')
  import tool_manager_ui
  tool_manager_ui.show()

Usage (standalone, outside Nuke)
---------------------------------
  python tool_manager_ui.py
"""

import os
import sys
import threading



# ── PySide compatibility Layer ────────────────────────────────────────────────
try:
    # Attempt PySide6 (Qt6)
    from PySide6 import QtWidgets, QtCore, QtGui
    from PySide6.QtCore import Qt, Signal, QObject, QTimer, QUrl, Slot
    from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QPushButton, 
                                 QLabel, QGraphicsDropShadowEffect, QHBoxLayout)
    from PySide6.QtGui import QDesktopServices, QFont, QColor, QIcon
    PYSIDE = 6
    def _exec(app): return app.exec()
    
except ImportError:
    # Fallback to PySide2 (Qt5)
    from PySide2 import QtWidgets, QtCore, QtGui
    from PySide2.QtCore import Qt, Signal, QObject, QTimer, QUrl, Slot
    from PySide2.QtWidgets import (QApplication, QWidget, QVBoxLayout, QPushButton, 
                                  QLabel, QGraphicsDropShadowEffect, QHBoxLayout)
    from PySide2.QtGui import QDesktopServices, QFont, QColor, QIcon
    PYSIDE = 2
    def _exec(app): return app.exec_()

# ── Sound Utilities ───────────────────────────────────────────────────────────
try:
    from sound_utils import play_async as _play_sound, SOUNDS, show_picker as _choose_sound
except ImportError:
    # Fallback if sound_utils is not in the path
    _play_sound = lambda x: print(f"Playing sound: {x}")
    SOUNDS = {}
    _choose_sound = lambda: print("Sound picker opened")






from zip_utils import (
    zip_folder,
    install_from_zip,
    install_from_folder,
    uninstall_tool,
    get_installed_tools,
    list_zip_contents,
    register_tool_path,
    register_nuke_plugin_path,
    register_all_installed,
    TOOLS_DIR,
)




def _read_init_py_paths() -> list:
    """
    Return list of dicts: [{path, line_raw, version}] for every
    nuke.pluginAddPath() entry in ~/.nuke/init.py.
    version is the major-version int from a surrounding  if block, or None.
    """
    import re as _re
    init_path = os.path.join(os.path.expanduser("~"), ".nuke", "init.py")
    if not os.path.isfile(init_path):
        return []

    entries  = []
    cur_ver  = None

    with open(init_path, "r", encoding="utf-8") as fh:
        for line in fh:
            # Detect  if nuke.NUKE_VERSION_MAJOR == N:
            vm = _re.match(r"if nuke\.NUKE_VERSION_MAJOR\s*==\s*(\d+)\s*:", line.strip())
            if vm:
                cur_ver = int(vm.group(1))
                continue
            # Detect un-indented code (end of version block)
            if line.strip() and not line.startswith("    ") and not line.strip().startswith("#"):
                cur_ver = None

            pm = _re.search(r"""pluginAddPath\s*\(\s*r?["'](.*?)["'\s]""", line)
            if pm:
                entries.append({
                    "path":     pm.group(1),
                    "line_raw": line.rstrip(),
                    "version":  cur_ver,
                })
    return entries


def _remove_from_init_py(path_to_remove: str) -> tuple:
    """
    Remove all nuke.pluginAddPath() lines that reference path_to_remove
    from ~/.nuke/init.py.  Empty version-guard blocks are cleaned up too.
    Returns (removed_count, init_path).
    """
    import re as _re
    init_path = os.path.join(os.path.expanduser("~"), ".nuke", "init.py")
    if not os.path.isfile(init_path):
        return 0, init_path

    with open(init_path, "r", encoding="utf-8") as fh:
        lines = fh.readlines()

    target = path_to_remove.replace("\\", "/").rstrip("/")
    new_lines = []
    removed   = 0

    for line in lines:
        m = _re.search(r"""pluginAddPath\s*\(\s*r?["'](.*?)["'\s]""", line)
        if m:
            lp = m.group(1).replace("\\", "/").rstrip("/")
            if lp == target:
                removed += 1
                continue
        new_lines.append(line)

    # Remove empty  if nuke.NUKE_VERSION_MAJOR == N:  blocks
    cleaned, j = [], 0
    while j < len(new_lines):
        l = new_lines[j]
        if _re.match(r"if nuke\.NUKE_VERSION_MAJOR\s*==\s*\d+\s*:", l.strip()):
            block = [l]
            j += 1
            while j < len(new_lines) and (new_lines[j].startswith("    ") or new_lines[j].strip() == ""):
                block.append(new_lines[j])
                j += 1
            if any(b.strip() and not b.strip().startswith("#") for b in block[1:]):
                cleaned.extend(block)
        else:
            cleaned.append(l)
            j += 1

    with open(init_path, "w", encoding="utf-8") as fh:
        fh.writelines(cleaned)

    return removed, init_path


class _InitPathPickerDialog(QtWidgets.QDialog):
    """
    Shows all nuke.pluginAddPath() lines from init.py and lets
    the user choose one or more to delete.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Remove from init.py — Select entries to delete")
        self.resize(680, 380)
        self.setStyleSheet("""
            QDialog { background: #252525; color: #d0d0d0; }
            QListWidget {
                background: #1a1a1a; border: 1px solid #3a3a3a;
                border-radius: 3px; color: #d0d0d0; font-family: Courier New; font-size: 11px;
            }
            QListWidget::item:selected { background: #804000; color: #fff; }
            QListWidget::item:hover    { background: #2e2e2e; }
            QPushButton {
                background: #333; border: 1px solid #4a4a4a;
                border-radius: 4px; padding: 5px 16px; color: #d0d0d0; min-height: 26px;
            }
            QPushButton:hover  { border-color: #f0a500; color: #fff; }
            QPushButton#danger {
                background: #5a1a1a; border: 1px solid #b03030; color: #ff9090;
            }
            QPushButton#danger:hover { background: #7a2a2a; }
            QLabel { color: #aaa; font-size: 12px; }
        """)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setSpacing(10)

        self._entries = _read_init_py_paths()

        if not self._entries:
            layout.addWidget(QtWidgets.QLabel(
                "  ~/.nuke/init.py not found or contains no pluginAddPath() entries."
            ))
            btn = QtWidgets.QPushButton("Close")
            btn.clicked.connect(self.reject)
            layout.addWidget(btn)
            return

        lbl = QtWidgets.QLabel(
            f"Found {len(self._entries)} path(s) in ~/.nuke/init.py.\n"
            "Select one or more to remove, then click Delete Selected."
        )
        lbl.setWordWrap(True)
        layout.addWidget(lbl)

        self.list_w = QtWidgets.QListWidget()
        self.list_w.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        for e in self._entries:
            ver_tag = f"  [Nuke {e['version']}]" if e['version'] else "  [all versions]"
            item = QtWidgets.QListWidgetItem(f"{e['path']}{ver_tag}")
            item.setData(Qt.UserRole, e['path'])
            self.list_w.addItem(item)
        layout.addWidget(self.list_w, 1)

        btn_row = QtWidgets.QHBoxLayout()
        sel_all = QtWidgets.QPushButton("Select All")
        sel_all.clicked.connect(self.list_w.selectAll)
        btn_row.addWidget(sel_all)
        btn_row.addStretch()

        cancel = QtWidgets.QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        btn_row.addWidget(cancel)

        self.del_btn = QtWidgets.QPushButton("Delete Selected")
        self.del_btn.setObjectName("danger")
        self.del_btn.clicked.connect(self._delete)
        btn_row.addWidget(self.del_btn)
        layout.addLayout(btn_row)

        self.result_paths = []   # populated after deletion

    def _delete(self):
        selected = self.list_w.selectedItems()
        if not selected:
            QtWidgets.QMessageBox.warning(self, "Nothing selected",
                                          "Select at least one entry to delete.")
            return
        self.result_paths = [it.data(Qt.UserRole) for it in selected]
        self.accept()


# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
#                     don't touch and function  stylesheet                     #



# def build_stylesheet(name):
#     """Generate full QSS for the given theme name."""
#     # Safety: Fallback to a default theme if the requested one doesn't exist
#     t = THEMES.get(name, THEMES.get(_DEFAULT_THEME))
    
#     if not t:
#         return ""

#     # Note: Double braces {{ }} are used so .format() renders them as 
#     # single braces { } in the final QSS string.
#     return ("""
#     * {{ box-sizing: border-box; }}
#     QWidget {{
#         background-color: {bg_base}; color: {txt};
#         font-family: "Segoe UI", Arial, sans-serif; font-size: 12px;
#     }}
#     QMainWindow {{ background: {bg_win}; }}
#     QLabel#title {{
#         font-size: 20px; font-weight: bold; color: {txt_h};
#         padding: 2px 0 4px 0; letter-spacing: 1px;
#     }}
#     QLabel#badge {{
#         font-size: 10px; color: {txt_dim}; background: {bg_dark};
#         border: 1px solid {brd}; border-radius: 3px; padding: 2px 6px;
#     }}
#     QTabWidget::pane {{
#         border: 1px solid {brd}; border-top: none;
#         border-radius: 0 4px 4px 4px; background: {bg_base};
#     }}
#     QTabBar::tab {{
#         background: {bg_win}; color: {txt_dim}; padding: 8px 20px;
#         border: 1px solid {brd}; border-bottom: none;
#         border-top-left-radius: 4px; border-top-right-radius: 4px; margin-right: 2px;
#     }}
#     QTabBar::tab:selected {{
#         background: {bg_base}; color: {txt_h}; font-weight: bold;
#         border-bottom-color: {bg_base};
#     }}
#     QTabBar::tab:hover:!selected {{ background: {bg_hover}; color: {txt}; }}
#     QPushButton {{
#         background: {bg_hover}; border: 1px solid {brd};
#         border-radius: 4px; padding: 5px 14px; color: {txt}; min-height: 24px;
#     }}
#     QPushButton:hover  {{ border-color: {acc}; color: {txt}; }}
#     QPushButton:pressed {{ background: {bg_dark}; }}
#     QPushButton:disabled {{ color: {txt_dim}; border-color: {brd_dim}; }}
#     QPushButton#primary {{
#         background: qlineargradient(x1:0,y1:0,x2:0,y2:1,
#             stop:0 {acc_hi}, stop:1 {acc_lo});
#         border: 1px solid {acc}; color: #fff; font-weight: bold; min-height: 32px;
#     }}
#     QPushButton#primary:hover  {{ background: {acc_hi}; }}
#     QPushButton#primary:pressed {{ background: {acc_lo}; }}
#     QPushButton#danger {{
#         background: {dng_bg}; border: 1px solid {dng_bd}; color: {dng_txt};
#     }}
#     QPushButton#danger:hover {{ background: {bg_hover}; }}
#     QPushButton#small {{ min-height: 20px; padding: 2px 8px; font-size: 11px; }}
#     QLineEdit, QTextEdit {{
#         background: {bg_input}; border: 1px solid {brd};
#         border-radius: 3px; color: {txt}; padding: 4px 6px;
#         selection-background-color: {acc}; selection-color: #000;
#     }}
#     QLineEdit:focus, QTextEdit:focus {{ border-color: {acc}; }}
#     QLineEdit:disabled {{ color: {txt_dim}; border-color: {brd_dim}; }}
#     QSpinBox, QComboBox {{
#         background: {bg_input}; border: 1px solid {brd};
#         border-radius: 3px; color: {txt}; padding: 3px 6px; min-height: 22px;
#     }}
#     QSpinBox:focus, QComboBox:focus {{ border-color: {acc}; }}
#     QComboBox::drop-down {{ border: none; width: 20px; background: {bg_hover}; }}
#     QComboBox QAbstractItemView {{
#         background: {bg_dark}; border: 1px solid {brd};
#         selection-background-color: {sel_bg}; color: {txt};
#     }}
#     QListWidget, QTreeWidget {{
#         background: {bg_dark}; border: 1px solid {brd};
#         border-radius: 3px; alternate-background-color: {bg_alt};
#         color: {txt}; outline: none;
#     }}
#     QListWidget::item:selected, QTreeWidget::item:selected {{
#         background: {sel_bg}; color: {sel_txt};
#     }}
#     QListWidget::item:hover, QTreeWidget::item:hover {{ background: {bg_hover}; }}
#     QHeaderView::section {{
#         background: {bg_base}; border: none;
#         border-right: 1px solid {brd}; border-bottom: 1px solid {brd};
#         padding: 5px 8px; color: {txt_dim}; font-weight: bold;
#     }}
#     QProgressBar {{
#         background: {bg_dark}; border: 1px solid {brd};
#         border-radius: 3px; height: 12px; text-align: center;
#         font-size: 10px; color: {txt_dim};
#     }}
#     QProgressBar::chunk {{
#         background: qlineargradient(x1:0,y1:0,x2:1,y2:0,
#             stop:0 {acc_lo}, stop:1 {acc}); border-radius: 2px;
#     }}
#     QGroupBox {{
#         border: 1px solid {brd}; border-radius: 4px;
#         margin-top: 14px; padding-top: 8px;
#         color: {txt_dim}; font-size: 11px; font-weight: bold;
#     }}
#     QGroupBox::title {{
#         subcontrol-origin: margin; left: 10px; padding: 0 4px; color: {txt_h};
#     }}
#     QCheckBox {{ spacing: 6px; color: {txt}; }}
#     QCheckBox::indicator {{
#         width: 14px; height: 14px; background: {bg_dark};
#         border: 1px solid {brd}; border-radius: 2px;
#     }}
#     QCheckBox::indicator:checked {{ background: {acc_hi}; border-color: {acc}; }}
#     QScrollBar:vertical {{ background: {bg_win}; width: 10px; margin: 0; }}
#     QScrollBar::handle:vertical {{
#         background: {brd}; border-radius: 4px; min-height: 20px;
#     }}
#     QScrollBar::handle:vertical:hover {{ background: {acc}; }}
#     QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
#     QScrollBar:horizontal {{ background: {bg_win}; height: 10px; }}
#     QScrollBar::handle:horizontal {{
#         background: {brd}; border-radius: 4px; min-width: 20px;
#     }}
#     QScrollBar::handle:horizontal:hover {{ background: {acc}; }}
#     QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}
#     QSplitter::handle {{ background: {brd}; }}
#     QSplitter::handle:horizontal {{ width: 2px; }}
#     QSplitter::handle:vertical   {{ height: 2px; }}
#     QFrame[frameShape="4"], QFrame[frameShape="5"] {{ color: {brd}; }}
#     QToolTip {{
#         background: {bg_dark}; border: 1px solid {acc};
#         color: {txt}; padding: 4px; border-radius: 3px;
#     }}
#     """).format(**t)

#     # ══════════════════════════════════════════════════════════════════════════════
#     # ══════════════════════════════════════════════════════════════════════════════
#     #                     don't touch and function  stylesheet                     #



# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# THEME ENGINE  ─  add more themes freely; they auto-appear in Settings
# ══════════════════════════════════════════════════════════════════════════════

THEMES = {
    "Dark Amber": dict(
        bg_win="#1e1e1e", bg_base="#252525", bg_dark="#1a1a1a",
        bg_alt="#202020", bg_hover="#2e2e2e", bg_input="#1a1a1a",
        acc="#f0a500", acc_lo="#a06000", acc_hi="#c88000",
        txt="#d0d0d0", txt_dim="#888", txt_h="#f0a500",
        brd="#3a3a3a", brd_dim="#2a2a2a",
        sel_bg="#804000", sel_txt="#fff",
        dng_bg="#5a1a1a", dng_bd="#b03030", dng_txt="#ff9090",
    ),
    "Dark Cyan": dict(
        bg_win="#1a1e22", bg_base="#222830", bg_dark="#161b20",
        bg_alt="#1c2228", bg_hover="#2a3340", bg_input="#161b20",
        acc="#00bcd4", acc_lo="#006070", acc_hi="#009aaf",
        txt="#ccd8e0", txt_dim="#6a8090", txt_h="#00bcd4",
        brd="#2a3a45", brd_dim="#1e2e38",
        sel_bg="#005f6b", sel_txt="#fff",
        dng_bg="#2a1515", dng_bd="#883333", dng_txt="#ff8080",
    ),
    "Dark Purple": dict(
        bg_win="#1c1a24", bg_base="#242030", bg_dark="#181520",
        bg_alt="#1e1c28", bg_hover="#2e2a40", bg_input="#181520",
        acc="#b084f0", acc_lo="#7050b0", acc_hi="#9060d0",
        txt="#d0cce0", txt_dim="#8878a0", txt_h="#b084f0",
        brd="#3a3050", brd_dim="#2a2040",
        sel_bg="#5a3888", sel_txt="#fff",
        dng_bg="#2a1520", dng_bd="#883050", dng_txt="#ff90c0",
    ),
    "Dark Green": dict(
        bg_win="#181e18", bg_base="#1e2820", bg_dark="#141a14",
        bg_alt="#182018", bg_hover="#253025", bg_input="#141a14",
        acc="#66bb6a", acc_lo="#388e3c", acc_hi="#4caf50",
        txt="#c8d8c8", txt_dim="#6a8868", txt_h="#66bb6a",
        brd="#2a3a2a", brd_dim="#1e2c1e",
        sel_bg="#2e6e30", sel_txt="#fff",
        dng_bg="#2a1515", dng_bd="#883333", dng_txt="#ff8080",
    ),
    "Slate Blue": dict(
        bg_win="#1e2235", bg_base="#252b42", bg_dark="#181d30",
        bg_alt="#1e2438", bg_hover="#2e3550", bg_input="#181d30",
        acc="#5c8eff", acc_lo="#2a55cc", acc_hi="#4070e0",
        txt="#c8d0e8", txt_dim="#6878a8", txt_h="#5c8eff",
        brd="#303858", brd_dim="#222848",
        sel_bg="#304890", sel_txt="#fff",
        dng_bg="#2a1525", dng_bd="#883050", dng_txt="#ff90b0",
    ),
    "Warm Charcoal": dict(
        bg_win="#1e1c1a", bg_base="#2a2724", bg_dark="#1a1816",
        bg_alt="#222018", bg_hover="#34302c", bg_input="#1a1816",
        acc="#ef8354", acc_lo="#a05030", acc_hi="#c86040",
        txt="#d8cec4", txt_dim="#887870", txt_h="#ef8354",
        brd="#3e3830", brd_dim="#2e2820",
        sel_bg="#8a4428", sel_txt="#fff",
        dng_bg="#2a1515", dng_bd="#883333", dng_txt="#ff9090",
    ),
    "Nuke Dark": dict(
        bg_win="#282828", bg_base="#303030", bg_dark="#242424",
        bg_alt="#2c2c2c", bg_hover="#3a3a3a", bg_input="#242424",
        acc="#c8a000", acc_lo="#806000", acc_hi="#a07800",
        txt="#c8c8c8", txt_dim="#787878", txt_h="#c8a000",
        brd="#484848", brd_dim="#383838",
        sel_bg="#786000", sel_txt="#fff",
        dng_bg="#501818", dng_bd="#a02828", dng_txt="#ff8888",
    ),
    "Light": dict(
        bg_win="#e0e0e0", bg_base="#f0f0f0", bg_dark="#d8d8d8",
        bg_alt="#e8e8e8", bg_hover="#dcdcdc", bg_input="#ffffff",
        acc="#1565c0", acc_lo="#0d47a1", acc_hi="#1976d2",
        txt="#212121", txt_dim="#757575", txt_h="#1565c0",
        brd="#bdbdbd", brd_dim="#cccccc",
        sel_bg="#1565c0", sel_txt="#fff",
        dng_bg="#ffebee", dng_bd="#e53935", dng_txt="#c62828",
    ),
}

_DEFAULT_THEME = "Dark Amber"

def build_stylesheet(name):
    t = THEMES.get(name, THEMES.get(_DEFAULT_THEME))
    if not t: return ""
    return ("""
    QWidget {{ background-color: {bg_base}; color: {txt}; }}
    /* ... rest of your QSS ... */
    """).format(**t)

# The call that was failing
full_qss = build_stylesheet(_DEFAULT_THEME)

# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# THEME ENGINE  ─  add more themes freely; they auto-appear in Settings
# ══════════════════════════════════════════════════════════════════════════════




# ══════════════════════════════════════════════════════════════════════════════
# LOG WIDGET  (thread-safe)
# ══════════════════════════════════════════════════════════════════════════════


class ToggleSwitch(QtWidgets.QPushButton):
    def __init__(self, icon_on, icon_off, size=24, parent=None):
        super(ToggleSwitch, self).__init__(parent)

        self.setCheckable(True)
        self.setCursor(QtCore.Qt.PointingHandCursor)
        self.setFixedSize(size + 8, size + 8)

        # Remove button styling
        self.setStyleSheet("""
        QPushButton {
            border: none;
            background: transparent;
        }
        """)

        # Setup icon states
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(icon_off), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        icon.addPixmap(QtGui.QPixmap(icon_on),  QtGui.QIcon.Normal, QtGui.QIcon.On)

        self.setIcon(icon)
        self.setIconSize(QtCore.QSize(size, size))


class _LogSignals(QObject):
    message = Signal(str)


class LogWidget(QtWidgets.QTextEdit):
    """Thread-safe, colour-coded log output panel."""

    COLOURS = {
        'info':  '#c8c8c8',
        'ok':    '#7dc87d',
        'warn':  '#f0c050',
        'error': '#e06060',
        'debug': '#7090b0',
        'title': '#f0a500',
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont("Courier New", 10))
        self.setLineWrapMode(QtWidgets.QTextEdit.NoWrap)
        self._sig = _LogSignals()
        self._sig.message.connect(self._do_append)

    def log(self, msg: str, level: str = 'info'):
        colour  = self.COLOURS.get(level, self.COLOURS['info'])
        escaped = (msg.replace('&', '&amp;')
                      .replace('<', '&lt;')
                      .replace('>', '&gt;'))
        html = f'<span style="color:{colour}">{escaped}</span>'
        self._sig.message.emit(html)

    def _do_append(self, html: str):
        self.append(html)
        sb = self.verticalScrollBar()
        sb.setValue(sb.maximum())

    def clear_log(self):
        self.clear()
        self.log('Log cleared.', 'debug')


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1b  —  INSTALL FROM FOLDER
# ══════════════════════════════════════════════════════════════════════════════

class FolderInstallTab(QtWidgets.QWidget):
    """
    Choose one or more tool folders and install them directly into ~/.nuke/tools
    without needing to create a .zip first.

    Features
    --------
    • Add multiple folders to a queue
    • Preview file tree for each selected folder
    • Overwrite toggle
    • Live session register (nuke.pluginAddPath)
    • Persistent init.py registration with version scoping
    • Per-folder and overall progress bars
    """

    def __init__(self, log: LogWidget, parent=None):
        super().__init__(parent)
        self.log = log
        self._build()

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(10)

        # ── Splitter: left = folder queue / right = file preview ──────────────
        splitter = QtWidgets.QSplitter(Qt.Horizontal)

        # ── LEFT: folder queue ────────────────────────────────────────────────
        left_w  = QtWidgets.QWidget()
        left_l  = QtWidgets.QVBoxLayout(left_w)
        left_l.setContentsMargins(0, 0, 6, 0)
        left_l.setSpacing(6)

        lbl = QtWidgets.QLabel("Tool Folders to Install")
        lbl.setStyleSheet("font-weight:bold; color:#aaa; font-size: 14px;")
        left_l.addWidget(lbl)

        # Folder list
        self.folder_list = QtWidgets.QListWidget()
        self.folder_list.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.folder_list.setMinimumWidth(220)
        self.folder_list.itemSelectionChanged.connect(self._on_folder_selected)
        self.folder_list.setToolTip("Select items then click Remove to delete them")
        left_l.addWidget(self.folder_list, 1)

        # Folder queue toolbar
        q_toolbar = QtWidgets.QHBoxLayout()
        self.add_btn = QtWidgets.QPushButton("Add Folder")
        self.add_btn.clicked.connect(self._add_folder)
        base_dir = os.path.dirname(__file__)
        icon_path = os.path.join(base_dir, "icons", "add-folder.png")
        self.add_btn.setIcon(QtGui.QIcon(icon_path))
        self.add_btn.setIconSize(QtCore.QSize(24, 24))
        q_toolbar.addWidget(self.add_btn)

        self.add_multi_btn = QtWidgets.QPushButton("Add Multiple…")
        self.add_multi_btn.setToolTip("Open the folder browser multiple times to queue several folders")
        self.add_multi_btn.clicked.connect(self._add_multiple_folders)
        icon_path = os.path.join(base_dir, "icons", "Add Multiple.png")
        self.add_multi_btn.setIcon(QtGui.QIcon(icon_path))
        self.add_multi_btn.setIconSize(QtCore.QSize(24, 24))
        q_toolbar.addWidget(self.add_multi_btn)

        self.remove_btn = QtWidgets.QPushButton("Remove")
        self.remove_btn.setObjectName("danger")
        icon_path = os.path.join(base_dir, "icons", "removed.png")
        self.remove_btn.setIcon(QtGui.QIcon(icon_path))
        self.remove_btn.setIconSize(QtCore.QSize(24, 24))
        self.remove_btn.setEnabled(False)
        self.remove_btn.clicked.connect(self._remove_selected)
        q_toolbar.addWidget(self.remove_btn)

        self.clear_btn = QtWidgets.QPushButton("Clear All")
        self.clear_btn.clicked.connect(self.folder_list.clear)
        icon_path = os.path.join(base_dir, "icons", "clear.png")
        self.clear_btn.setIcon(QtGui.QIcon(icon_path))
        self.clear_btn.setIconSize(QtCore.QSize(24, 24))
        q_toolbar.addWidget(self.clear_btn)
        left_l.addLayout(q_toolbar)

        # Folder count label
        self.queue_lbl = QtWidgets.QLabel("0 folder(s) queued")
        self.queue_lbl.setStyleSheet("color:#888; font-size:11px;")
        self.folder_list.model().rowsInserted.connect(self._update_queue_lbl)
        self.folder_list.model().rowsRemoved.connect(self._update_queue_lbl)
        left_l.addWidget(self.queue_lbl)

        splitter.addWidget(left_w)

        # ── RIGHT: file tree preview ──────────────────────────────────────────
        right_w = QtWidgets.QWidget()
        right_l = QtWidgets.QVBoxLayout(right_w)
        right_l.setContentsMargins(6, 0, 0, 0)
        right_l.setSpacing(6)

        # Header row: label + buttons
        prev_header = QtWidgets.QHBoxLayout()
        prev_lbl = QtWidgets.QLabel("File Preview  (click a folder to preview)")
        prev_lbl.setStyleSheet("font-weight:bold; color:#aaa;")
        prev_header.addWidget(prev_lbl)
        prev_header.addStretch()

        self.expand_btn = QtWidgets.QPushButton("⊞")
        self.expand_btn.setObjectName("small")
        self.expand_btn.setFixedWidth(64)
        self.expand_btn.setToolTip("Expand All")
        self.expand_btn.setEnabled(False)
        prev_header.addWidget(self.expand_btn)

        self.collapse_btn = QtWidgets.QPushButton("⊟")
        self.collapse_btn.setObjectName("small")
        self.collapse_btn.setFixedWidth(64)
        self.collapse_btn.setToolTip("Collapse All")
        self.collapse_btn.setEnabled(False)
        prev_header.addWidget(self.collapse_btn)

        self.refresh_preview_btn = QtWidgets.QPushButton("Refresh Preview")
        self.refresh_preview_btn.setObjectName("small")
        self.refresh_preview_btn.setToolTip("Re-scan the selected folder and refresh the file tree")
        self.refresh_preview_btn.setEnabled(False)
        self.refresh_preview_btn.clicked.connect(self._refresh_preview)
        icon_path = os.path.join(base_dir, "icons", "refresh-data.png")
        self.refresh_preview_btn.setIcon(QtGui.QIcon(icon_path))
        self.refresh_preview_btn.setIconSize(QtCore.QSize(24, 24))
        prev_header.addWidget(self.refresh_preview_btn)

        right_l.addLayout(prev_header)

        self.preview_tree = QtWidgets.QTreeWidget()
        self.preview_tree.setHeaderLabels(['Name', 'Size', 'Type'])
        self.preview_tree.setColumnWidth(0, 220)
        self.preview_tree.setColumnWidth(1, 60)
        self.preview_tree.setAlternatingRowColors(True)
        right_l.addWidget(self.preview_tree, 1)

        # Wire expand/collapse now that preview_tree exists
        self.expand_btn.clicked.connect(self.preview_tree.expandAll)
        self.collapse_btn.clicked.connect(self.preview_tree.collapseAll)

        self.preview_stats = QtWidgets.QLabel("")
        self.preview_stats.setStyleSheet("color:#888; font-size:11px;")
        right_l.addWidget(self.preview_stats)

        splitter.addWidget(right_w)
        splitter.setSizes([260, 380])
        outer.addWidget(splitter, 1)

        # ── Install Destination ───────────────────────────────────────────────
        grp_dst = QtWidgets.QGroupBox("Install Destination")
        grp_dst.setStyleSheet("QGroupBox { font-weight: bold; font-size: 16px; }")
        dst_l   = QtWidgets.QHBoxLayout(grp_dst)
        self.dst_edit = QtWidgets.QLineEdit()
        self.dst_edit.setPlaceholderText(f"Default: {TOOLS_DIR}/<~ nuke>/  (one dir per folder)")
        self.dst_edit.textChanged.connect(self._refresh_init_preview)
        dst_l.addWidget(self.dst_edit)
        dst_btn = QtWidgets.QPushButton("Browse…")
        dst_btn.setStyleSheet("QPushButton { font-weight: bold; font-size: 14px; }")
        dst_btn.clicked.connect(self._browse_dst)
        dst_l.addWidget(dst_btn)
        outer.addWidget(grp_dst)

        # ── Options row ───────────────────────────────────────────────────────
        opt_l = QtWidgets.QHBoxLayout()
        self.overwrite_cb = QtWidgets.QCheckBox("Overwrite existing files")
        self.overwrite_cb.setChecked(True)
        self.register_cb  = QtWidgets.QCheckBox("Register with Nuke (live session)")
        self.register_cb.setChecked(True)
        opt_l.addWidget(self.overwrite_cb)
        opt_l.addSpacing(20)
        opt_l.addWidget(self.register_cb)
        opt_l.addStretch()
        outer.addLayout(opt_l)

        # # ── Persistent init.py registration ───────────────────────────────────
        # grp_init = QtWidgets.QGroupBox(
        #     "Persistent init.py Registration  (~/.nuke/init.py)"
        # )
        # grp_init.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; }")
        # init_grid = QtWidgets.QGridLayout(grp_init)
        # init_grid.setColumnStretch(1, 1)

        # self.write_init_cb = QtWidgets.QCheckBox(
        #     "Write nuke.pluginAddPath() to init.py"
        # )
        # self.write_init_cb.setChecked(True)
        # self.write_init_cb.toggled.connect(self._on_write_init_toggled)
        # init_grid.addWidget(self.write_init_cb, 0, 0, 1, 3)

        # init_grid.addWidget(QtWidgets.QLabel("Nuke version:"), 1, 0)

        # self.nuke_ver_edit = QtWidgets.QComboBox()
        # self.nuke_ver_edit.setEditable(True)

        # _nuke_versions = [
        #     "17.1", "17.0",
        #     "16.1", "16.0",
        #     "15.1", "15.0",
        #     "14.2", "14.1", "14.0",
        #     "13.2", "13.1", "13.0",
        #     "12.2", "12.1", "12.0",
        #     "11.3", "11.2", "11.1", "11.0",
        # ]
        # _current_ver = ""
        # try:
        #     import nuke
        #     _current_ver = f"{nuke.NUKE_VERSION_MAJOR}.{nuke.NUKE_VERSION_MINOR}"
        #     if _current_ver not in _nuke_versions:
        #         _nuke_versions.insert(0, _current_ver)
        # except Exception:
        #     pass

        # self.nuke_ver_edit.addItems(_nuke_versions)
        # if _current_ver and _current_ver in _nuke_versions:
        #     self.nuke_ver_edit.setCurrentText(_current_ver)

        # self.nuke_ver_edit.currentTextChanged.connect(self._refresh_init_preview)
        # init_grid.addWidget(self.nuke_ver_edit, 1, 1)

        # icon_off = os.path.join(base_dir, "icons", "toggle_off.png")
        # icon_on  = os.path.join(base_dir, "icons", "toggle_on.png")
        # self.major_only_toggle = ToggleSwitch(icon_on, icon_off, size=64)
        # self.major_only_toggle.setChecked(True)
        # self.major_only_toggle.setToolTip(
        #     "When enabled, register only for the specified MAJOR version."
        # )
        # self.major_only_toggle.toggled.connect(self._refresh_init_preview)
        # init_grid.addWidget(self.major_only_toggle, 1, 2)

        # self.init_preview_lbl = QtWidgets.QLabel("(add a folder to see preview)")
        # self.init_preview_lbl.setStyleSheet("""
        #     font-family: 'Courier New', monospace;
        #     font-size: 10px;
        #     color: #aaa;
        #     background: #1a1a1a;
        #     border: 1px solid #333;
        #     border-radius: 4px;
        #     padding: 6px;
        # """)
        # self.init_preview_lbl.setWordWrap(True)
        # init_grid.addWidget(self.init_preview_lbl, 2, 0, 1, 3)

        # # Remove-from-init.py button row
        # rem_row = QtWidgets.QHBoxLayout()
        # self.remove_init_btn = QtWidgets.QPushButton("Remove Path from init.py")
        # self.remove_init_btn.setObjectName("danger")
        # self.remove_init_btn.setToolTip(
        #     "Delete the nuke.pluginAddPath() line for the selected folder from ~/.nuke/init.py"
        # )
        # self.remove_init_btn.clicked.connect(self._remove_from_init)
        # rem_row.addStretch()
        # rem_row.addWidget(self.remove_init_btn)
        # init_grid.addLayout(rem_row, 3, 0, 1, 3)

        # outer.addWidget(grp_init)

        # ── Persistent init.py registration ───────────────────────────────────
        grp_init = QtWidgets.QGroupBox(
            "Persistent init.py Registration  (~/.nuke/init.py)"
        )

        grp_init.setStyleSheet("""
        QGroupBox {
            border: 1px solid #333;
            border-radius: 4px;
            margin-top: 12px;
        }

        QGroupBox::title {
            subcontrol-origin: margin;
            left: 12px;
            padding: 0 6px 0 6px;
            font-weight: bold;
            font-size: 14px;
        }
        """)

        init_grid = QtWidgets.QGridLayout(grp_init)
        init_grid.setColumnStretch(1, 1)

        self.write_init_cb = QtWidgets.QCheckBox(
            "Write nuke.pluginAddPath() to init.py"
        )
        self.write_init_cb.setChecked(True)
        self.write_init_cb.toggled.connect(self._on_write_init_toggled)
        init_grid.addWidget(self.write_init_cb, 0, 0, 1, 3)

        # --- Nuke Version Label (also bold 14pt for consistency) ---
        label_version = QtWidgets.QLabel("Nuke version:")
        font = label_version.font()
        font.setPointSize(14)
        font.setBold(True)
        label_version.setFont(font)
        init_grid.addWidget(label_version, 1, 0)

        self.nuke_ver_edit = QtWidgets.QComboBox()
        self.nuke_ver_edit.setEditable(True)

        _nuke_versions = [
            "17.1", "17.0",
            "16.1", "16.0",
            "15.1", "15.0",
            "14.2", "14.1", "14.0",
            "13.2", "13.1", "13.0",
            "12.2", "12.1", "12.0",
            "11.3", "11.2", "11.1", "11.0",
        ]

        _current_ver = ""
        try:
            import nuke
            _current_ver = f"{nuke.NUKE_VERSION_MAJOR}.{nuke.NUKE_VERSION_MINOR}"
            if _current_ver not in _nuke_versions:
                _nuke_versions.insert(0, _current_ver)
        except Exception:
            pass

        self.nuke_ver_edit.addItems(_nuke_versions)

        if _current_ver and _current_ver in _nuke_versions:
            self.nuke_ver_edit.setCurrentText(_current_ver)

        self.nuke_ver_edit.currentTextChanged.connect(self._refresh_init_preview)
        init_grid.addWidget(self.nuke_ver_edit, 1, 1)

        icon_off = os.path.join(base_dir, "icons", "toggle_off.png")
        icon_on  = os.path.join(base_dir, "icons", "toggle_on.png")

        self.major_only_toggle = ToggleSwitch(icon_on, icon_off, size=64)
        self.major_only_toggle.setChecked(True)
        self.major_only_toggle.setToolTip(
            "When enabled, register only for the specified MAJOR version."
        )
        self.major_only_toggle.toggled.connect(self._refresh_init_preview)
        init_grid.addWidget(self.major_only_toggle, 1, 2)

        self.init_preview_lbl = QtWidgets.QLabel("(add a folder to see preview)")
        self.init_preview_lbl.setStyleSheet("""
            font-family: 'Courier New', monospace;
            font-size: 16px;
            color: #aaa;
            background: #1a1a1a;
            border: 1px solid #333;
            border-radius: 4px;
            padding: 6px;
        """)
        self.init_preview_lbl.setWordWrap(True)
        init_grid.addWidget(self.init_preview_lbl, 2, 0, 1, 3)

        # Remove-from-init.py button row
        rem_row = QtWidgets.QHBoxLayout()
        self.remove_init_btn = QtWidgets.QPushButton("Remove Path from init.py")
        self.remove_init_btn.setStyleSheet("color: white; font-weight: bold; font-size: 14px")
        self.remove_init_btn.setObjectName("danger")
        self.remove_init_btn.setToolTip(
            "Delete the nuke.pluginAddPath() line for the selected folder from ~/.nuke/init.py"
        )
        self.remove_init_btn.clicked.connect(self._remove_from_init)

        rem_row.addStretch()
        rem_row.addWidget(self.remove_init_btn)

        init_grid.addLayout(rem_row, 3, 0, 1, 3)

        outer.addWidget(grp_init)

        # ── Progress ──────────────────────────────────────────────────────────
        prog_grp  = QtWidgets.QGroupBox("Progress")
        prog_l    = QtWidgets.QVBoxLayout(prog_grp)

        file_row  = QtWidgets.QHBoxLayout()
        file_row.addWidget(QtWidgets.QLabel("Current:"))
        self.progress_file = QtWidgets.QProgressBar()
        self.progress_file.setRange(0, 100)
        file_row.addWidget(self.progress_file)
        prog_l.addLayout(file_row)

        total_row = QtWidgets.QHBoxLayout()
        total_row.addWidget(QtWidgets.QLabel("Overall: "))
        self.progress_total = QtWidgets.QProgressBar()
        self.progress_total.setRange(0, 100)
        total_row.addWidget(self.progress_total)
        prog_l.addLayout(total_row)

        prog_grp.setVisible(False)
        self.prog_grp = prog_grp
        outer.addWidget(prog_grp)

        # ── Bottom row: sound toggle + install button ──────────────────────────
        bottom_row = QtWidgets.QHBoxLayout()

        self.sound_cb = QtWidgets.QCheckBox("Play sound on complete")
        self.sound_cb.setChecked(True)
        icon_path = os.path.join(base_dir, "icons", "volume.png")
        self.sound_cb.setIcon(QtGui.QIcon(icon_path))
        self.sound_cb.setIconSize(QtCore.QSize(24, 24))
        self.sound_cb.setToolTip(
            "Play a chime when all folders finish installing.\n"
            "Sound file: install_complete.wav  (same folder as this script)"
        )
        bottom_row.addWidget(self.sound_cb)

        self.test_snd_btn = QtWidgets.QPushButton("▶")
        self.test_snd_btn.setObjectName("small")
        icon_path = os.path.join(base_dir, "icons", "music.png")
        self.test_snd_btn.setIcon(QtGui.QIcon(icon_path))
        self.test_snd_btn.setIconSize(QtCore.QSize(24, 24))
        self.test_snd_btn.setFixedWidth(64)
        self.test_snd_btn.setToolTip("Preview the chosen install sound")
        self.test_snd_btn.clicked.connect(lambda: _play_sound())
        bottom_row.addWidget(self.test_snd_btn)

        self.choose_snd_btn = QtWidgets.QPushButton("Choose Sound…")
        self.choose_snd_btn.setObjectName("small")
        self.choose_snd_btn.setToolTip("Pick which WAV plays when installation completes")
        self.choose_snd_btn.clicked.connect(lambda: _choose_sound(self))
        bottom_row.addWidget(self.choose_snd_btn)

        bottom_row.addStretch()

        self.install_btn = QtWidgets.QPushButton("Install Tools")
        self.install_btn.setStyleSheet("color:white; font-weight: bold; font-size: 14px; background-color: #003d00;")
        self.install_btn.setObjectName("primary")
        self.install_btn.setMinimumHeight(38)
        self.install_btn.setEnabled(False)
        icon_path = os.path.join(base_dir, "icons", "installation.png")
        self.install_btn.setIcon(QtGui.QIcon(icon_path))
        self.install_btn.setIconSize(QtCore.QSize(32, 32))
        self.install_btn.clicked.connect(self._install)
        bottom_row.addWidget(self.install_btn)

        outer.addLayout(bottom_row)

    # ── Slots ──────────────────────────────────────────────────────────────────

    def _update_queue_lbl(self):
        n = self.folder_list.count()
        self.queue_lbl.setText(f"{n} folder(s) queued")
        self.install_btn.setEnabled(n > 0)
        self._refresh_init_preview()

    def _on_folder_selected(self):
        sel = self.folder_list.selectedItems()
        self.remove_btn.setEnabled(bool(sel))
        has_sel = bool(sel)
        self.refresh_preview_btn.setEnabled(has_sel)
        self.expand_btn.setEnabled(has_sel)
        self.collapse_btn.setEnabled(has_sel)
        if sel:
            self._preview_folder(sel[0].data(Qt.UserRole))

    def _add_folder(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Tools Folder", os.path.expanduser('~')
        )
        if path:
            self._queue_folder(path)

    def _add_multiple_folders(self):
        """Keep opening the dialog until the user cancels."""
        while True:
            path = QtWidgets.QFileDialog.getExistingDirectory(
                self, "Select Tools Folder  (Cancel to stop adding)", os.path.expanduser('~')
            )
            if not path:
                break
            self._queue_folder(path)

    def _refresh_preview(self):
        """Re-scan the currently selected folder and rebuild the file tree."""
        sel = self.folder_list.selectedItems()
        if not sel:
            return
        folder_path = sel[0].data(Qt.UserRole)
        self.log.log(f"⟳  Refreshing preview: {os.path.basename(folder_path)}", 'debug')
        self._preview_folder(folder_path)

    def _queue_folder(self, path):
        path = os.path.normpath(path)
        # Avoid duplicates
        for i in range(self.folder_list.count()):
            if self.folder_list.item(i).data(Qt.UserRole) == path:
                self.log.log(f"Already queued: {path}", 'warn')
                return
        name = os.path.basename(path)
        item = QtWidgets.QListWidgetItem(f"{name}")
        item.setData(Qt.UserRole, path)
        item.setToolTip(path)
        self.folder_list.addItem(item)
        self.log.log(f"Queued: {path}", 'ok')
        self._refresh_init_preview()

    def _remove_selected(self):
        for item in self.folder_list.selectedItems():
            self.folder_list.takeItem(self.folder_list.row(item))

    def _browse_dst(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Install Destination", TOOLS_DIR
        )
        if path:
            self.dst_edit.setText(path)

    def _preview_folder(self, folder_path):
        """Populate the file tree with the contents of folder_path."""
        self.preview_tree.clear()
        if not folder_path or not os.path.isdir(folder_path):
            return

        total_files = 0
        total_bytes = 0

        def _walk(parent_item, dirpath):
            nonlocal total_files, total_bytes
            try:
                entries = sorted(os.scandir(dirpath), key=lambda e: (not e.is_dir(), e.name))
            except PermissionError:
                return
            for entry in entries:
                if entry.name.startswith('.') or entry.name in ('__pycache__', '.git', 'manifest.json'):
                    continue
                if entry.is_dir():
                    dir_item = QtWidgets.QTreeWidgetItem([f"📁 {entry.name}", "", "folder"])
                    dir_item.setForeground(0, QColor('#8ab4f8'))
                    parent_item.addChild(dir_item)
                    _walk(dir_item, entry.path)
                else:
                    ext  = os.path.splitext(entry.name)[1].lower()
                    size = entry.stat().st_size
                    total_files += 1
                    total_bytes += size

                    icon = {'.py': '🐍', '.nk': '🎬', '.gizmo': '⚙', '.json': '{}',
                            '.txt': '📄', '.md': '📄', '.png': '🖼', '.jpg': '🖼'}.get(ext, '📄')

                    size_s = (f"{size/1024:.1f} KB" if size >= 1024 else f"{size} B")
                    file_item = QtWidgets.QTreeWidgetItem(
                        [f"{icon} {entry.name}", size_s, ext or 'file']
                    )
                    file_item.setForeground(1, QColor('#888'))
                    file_item.setForeground(2, QColor('#666'))
                    parent_item.addChild(file_item)

        root_item = QtWidgets.QTreeWidgetItem(
            [f"📁 {os.path.basename(folder_path)}", "", "root"]
        )
        root_item.setForeground(0, QColor('#f0a500'))
        self.preview_tree.addTopLevelItem(root_item)
        _walk(root_item, folder_path)
        root_item.setExpanded(True)

        size_s = (f"{total_bytes/1024/1024:.1f} MB" if total_bytes >= 1024*1024
                  else f"{total_bytes/1024:.1f} KB")
        self.preview_stats.setText(
            f"{total_files} file(s)   {size_s}   —   {folder_path}"
        )

    def _on_write_init_toggled(self, checked):
        self.nuke_ver_edit.setEnabled(checked)
        self.major_only_toggle.setEnabled(checked)   # FIX: was major_only_cb
        self._refresh_init_preview()

    def _refresh_init_preview(self):
        if not self.write_init_cb.isChecked():
            self.init_preview_lbl.setText("(init.py registration disabled)")
            return

        # Determine example path
        if self.folder_list.count() > 0:
            first = self.folder_list.item(0).data(QtCore.Qt.UserRole)
            name  = os.path.basename(first)
            dst   = self.dst_edit.text().strip()
            if dst:
                example_path = dst.replace("\\", "/")
            else:
                example_path = os.path.join(TOOLS_DIR, name).replace("\\", "/")
        else:
            example_path = "<install_dir>"

        # Version parsing
        ver   = self.nuke_ver_edit.currentText().strip()
        major = ver.split(".")[0] if ver else "??"

        major_only = self.major_only_toggle.isChecked()   # FIX: was major_only_cb

        # Multi-folder note
        if self.folder_list.count() > 1:
            note = f"  # (repeated for each of {self.folder_list.count()} folders)"
        else:
            note = ""

        # Build preview text
        if major_only and major.isdigit():
            preview = (
                f'if nuke.NUKE_VERSION_MAJOR == {major}:\n'
                f'    nuke.pluginAddPath(r"{example_path}"){note}'
            )
        else:
            preview = f'nuke.pluginAddPath(r"{example_path}"){note}'

        self.init_preview_lbl.setText(
            "Will write to ~/.nuke/init.py:\n\n" + preview
        )

    def _remove_from_init(self):
        """Open picker dialog showing all init.py paths — user selects which to remove."""
        dlg = _InitPathPickerDialog(self)
        if not dlg.exec():
            return
        total = 0
        for path in dlg.result_paths:
            count, _ = _remove_from_init_py(path)
            total += count
            if count:
                self.log.log(f"Removed init.py entry: {path}", 'ok')
            else:
                self.log.log(f"Entry not found (already removed?): {path}", 'warn')
        if total:
            self.log.log(f"Total removed: {total} line(s) from init.py.", 'ok')
        self._refresh_init_preview()

    # ── Install ────────────────────────────────────────────────────────────────

    def _install(self):
        if self.folder_list.count() == 0:
            self.log.log("No folders queued.", 'warn')
            return

        nuke_ver   = self.nuke_ver_edit.currentText().strip()
        write_init = self.write_init_cb.isChecked()
        major_only = self.major_only_toggle.isChecked()   # FIX: was major_only_cb

        if write_init and not nuke_ver:
            self.log.log("Enter a Nuke version before writing to init.py.", 'warn')
            return

        # Collect folder paths
        folders = [
            self.folder_list.item(i).data(Qt.UserRole)
            for i in range(self.folder_list.count())
        ]

        dst         = self.dst_edit.text().strip() or None
        overwrite   = self.overwrite_cb.isChecked()
        register    = self.register_cb.isChecked()
        play_sound  = self.sound_cb.isChecked()
        total_fldrs = len(folders)

        self.install_btn.setEnabled(False)
        self.prog_grp.setVisible(True)
        self.progress_file.setValue(0)
        self.progress_total.setValue(0)

        def _set_progress(bar, val):
            QtCore.QMetaObject.invokeMethod(
                bar, "setValue",
                Qt.QueuedConnection, QtCore.Q_ARG(int, val)
            )

        def _run():
            succeeded = 0
            for fi, folder_path in enumerate(folders):
                name = os.path.basename(folder_path)
                self.log.log(f"[{fi+1}/{total_fldrs}]  Installing folder '{name}' …")

                def _file_progress(cur, tot, _fi=fi):
                    _set_progress(self.progress_file, int(cur/tot*100) if tot else 100)
                    overall = int((_fi + cur/tot) / total_fldrs * 100) if tot else 0
                    _set_progress(self.progress_total, overall)

                try:
                    dest = os.path.join(dst, name) if dst else None
                    installed = install_from_folder(
                        folder_path, dest, overwrite, _file_progress
                    )
                    self.log.log(f"Installed → {installed}", 'ok')

                    if register:
                        register_tool_path(installed)
                        self.log.log("Registered (live session).", 'ok')

                    if write_init:
                        register_nuke_plugin_path(installed, nuke_ver, major_only)
                        scope = f"Nuke {nuke_ver.split('.')[0]} only" if major_only else "all versions"
                        self.log.log(f"init.py written  ({scope}).", 'ok')

                    succeeded += 1

                except Exception as ex:
                    self.log.log(f"Failed '{name}': {ex}", 'error')

            _set_progress(self.progress_total, 100)
            self.log.log(
                f"Done — {succeeded}/{total_fldrs} folder(s) installed.", 'ok'
            )

            if play_sound and succeeded > 0:
                _play_sound()

            QtCore.QMetaObject.invokeMethod(
                self.prog_grp, "setVisible",
                Qt.QueuedConnection, QtCore.Q_ARG(bool, False)
            )
            QtCore.QMetaObject.invokeMethod(
                self.install_btn, "setEnabled",
                Qt.QueuedConnection, QtCore.Q_ARG(bool, True)
            )

        threading.Thread(target=_run, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2  —  INSTALL FROM ZIP
# ══════════════════════════════════════════════════════════════════════════════

class InstallTab(QtWidgets.QWidget):
    """Install tools from a .zip archive."""

    def __init__(self, log: LogWidget, parent=None):
        super().__init__(parent)
        self.log = log
        self._build()

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(10)

        # ── Source zip ────────────────────────────────────────────────────────
        grp_src = QtWidgets.QGroupBox("Source .zip File")
        grp_src.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; }")
        src_l   = QtWidgets.QHBoxLayout(grp_src)
        self.zip_edit = QtWidgets.QLineEdit()
        self.zip_edit.setPlaceholderText("Path to tools .zip …")
        self.zip_edit.textChanged.connect(self._on_zip_changed)
        src_l.addWidget(self.zip_edit)
        b = QtWidgets.QPushButton("Browse…")
        b.setStyleSheet("QPushButton { font-weight: bold; font-size: 14px; }")
        b.clicked.connect(self._browse_zip)
        src_l.addWidget(b)
        outer.addWidget(grp_src)

        # ── Destination ───────────────────────────────────────────────────────
        grp_dst = QtWidgets.QGroupBox("Install Destination")
        grp_dst.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; }")
        dst_l   = QtWidgets.QHBoxLayout(grp_dst)
        self.dst_edit = QtWidgets.QLineEdit()
        self.dst_edit.setPlaceholderText(f"Default: {TOOLS_DIR}/<~ nuke>")
        dst_l.addWidget(self.dst_edit)
        b2 = QtWidgets.QPushButton("Browse…")
        b2.setStyleSheet("QPushButton { font-weight: bold; font-size: 14px; }")
        b2.clicked.connect(self._browse_dst)
        dst_l.addWidget(b2)
        outer.addWidget(grp_dst)

        # ── Options ───────────────────────────────────────────────────────────
        opt_l = QtWidgets.QHBoxLayout()
        self.overwrite_cb = QtWidgets.QCheckBox("Overwrite existing files")
        self.overwrite_cb.setChecked(True)
        self.register_cb  = QtWidgets.QCheckBox("Auto-register path with Nuke after install")
        self.register_cb.setChecked(True)
        opt_l.addWidget(self.overwrite_cb)
        opt_l.addSpacing(20)
        opt_l.addWidget(self.register_cb)
        opt_l.addStretch()
        outer.addLayout(opt_l)

        # ── Persistent init.py registration ───────────────────────────────────
        grp_init = QtWidgets.QGroupBox(
            "Persistent init.py Registration  (~/.nuke/init.py)"
        )
        grp_init.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; }")
        init_grid = QtWidgets.QGridLayout(grp_init)
        init_grid.setColumnStretch(1, 1)

        self.write_init_cb = QtWidgets.QCheckBox(
            "Write nuke.pluginAddPath() to init.py"
        )
        self.write_init_cb.setChecked(True)
        self.write_init_cb.toggled.connect(self._refresh_init_preview)
        init_grid.addWidget(self.write_init_cb, 0, 0, 1, 3)

        # init_grid.addWidget(QtWidgets.QLabel("Nuke version:"), 1, 0)
        # --- Nuke Version Label (also bold 14pt for consistency) ---
        label_version = QtWidgets.QLabel("Nuke version:")
        font = label_version.font()
        font.setPointSize(14)
        font.setBold(True)
        label_version.setFont(font)
        init_grid.addWidget(label_version, 1, 0)

        self.nuke_ver_edit = QtWidgets.QComboBox()
        self.nuke_ver_edit.setEditable(True)

        _nuke_versions = [
            "17.1", "17.0",
            "16.1", "16.0",
            "15.1", "15.0",
            "14.2", "14.1", "14.0",
            "13.2", "13.1", "13.0",
            "12.2", "12.1", "12.0",
            "11.3", "11.2", "11.1", "11.0",
        ]
        _current_ver = ""
        try:
            import nuke
            _current_ver = f"{nuke.NUKE_VERSION_MAJOR}.{nuke.NUKE_VERSION_MINOR}"
            if _current_ver not in _nuke_versions:
                _nuke_versions.insert(0, _current_ver)
        except Exception:
            pass

        self.nuke_ver_edit.addItems(_nuke_versions)
        if _current_ver and _current_ver in _nuke_versions:
            self.nuke_ver_edit.setCurrentText(_current_ver)

        self.nuke_ver_edit.currentTextChanged.connect(self._refresh_init_preview)
        init_grid.addWidget(self.nuke_ver_edit, 1, 1)

        base_dir = os.path.dirname(__file__)
        icon_off = os.path.join(base_dir, "icons", "toggle_off.png")
        icon_on  = os.path.join(base_dir, "icons", "toggle_on.png")
        self.major_only_toggle = ToggleSwitch(icon_on, icon_off, size=64)
        self.major_only_toggle.setChecked(True)
        self.major_only_toggle.setToolTip(
            "Enabled → Wrap in:\n"
            "if nuke.NUKE_VERSION_MAJOR == N:\n"
            "    nuke.pluginAddPath(...)\n\n"
            "Disabled → Register for all Nuke versions."
        )
        self.major_only_toggle.toggled.connect(self._refresh_init_preview)
        init_grid.addWidget(self.major_only_toggle, 1, 2)

        self.init_preview_lbl = QtWidgets.QLabel("(add a folder to see preview)")
        self.init_preview_lbl.setStyleSheet("""
            font-family: 'Courier New', monospace;
            font-size: 16px;
            color: #aaa;
            background: #1a1a1a;
            border: 1px solid #333;
            border-radius: 4px;
            padding: 6px;
        """)
        self.init_preview_lbl.setWordWrap(True)
        init_grid.addWidget(self.init_preview_lbl, 2, 0, 1, 3)

        # Remove-from-init.py button row
        rem_row2 = QtWidgets.QHBoxLayout()
        self.remove_init_btn = QtWidgets.QPushButton("Remove Path from init.py")
        self.remove_init_btn.setObjectName("danger")
        self.remove_init_btn.setToolTip(
            "Delete the nuke.pluginAddPath() line for this zip's path from ~/.nuke/init.py"
        )
        self.remove_init_btn.clicked.connect(self._remove_from_init)
        rem_row2.addStretch()
        rem_row2.addWidget(self.remove_init_btn)
        init_grid.addLayout(rem_row2, 3, 0, 1, 3)

        outer.addWidget(grp_init)

        # ── Preview ───────────────────────────────────────────────────────────
        grp_prev = QtWidgets.QGroupBox("Zip Contents Preview")
        grp_prev.setStyleSheet("QGroupBox{font-size:14px font-weight: bold;}")
        prev_l   = QtWidgets.QVBoxLayout(grp_prev)

        prev_btn_l = QtWidgets.QHBoxLayout()
        self.prev_btn = QtWidgets.QPushButton("Preview Contents")
        self.prev_btn.setEnabled(False)
        self.prev_btn.clicked.connect(self._preview)
        prev_btn_l.addWidget(self.prev_btn)
        self.file_count_lbl = QtWidgets.QLabel("")
        self.file_count_lbl.setStyleSheet("color:#888; font-size:11px;")
        prev_btn_l.addWidget(self.file_count_lbl)
        prev_btn_l.addStretch()
        prev_l.addLayout(prev_btn_l)

        self.contents_tree = QtWidgets.QTreeWidget()
        self.contents_tree.setHeaderLabels(['File', 'Size', 'Compressed', 'Date'])
        self.contents_tree.setColumnWidth(0, 280)
        self.contents_tree.setColumnWidth(1, 70)
        self.contents_tree.setColumnWidth(2, 80)
        self.contents_tree.setMaximumHeight(160)
        self.contents_tree.setAlternatingRowColors(True)
        prev_l.addWidget(self.contents_tree)
        outer.addWidget(grp_prev)

        # ── Progress ──────────────────────────────────────────────────────────
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setVisible(False)
        outer.addWidget(self.progress)

        # ── Bottom row: sound + install ───────────────────────────────────────
        bottom_zip = QtWidgets.QHBoxLayout()

        self.sound_cb = QtWidgets.QCheckBox("Play sound on complete")
        self.sound_cb.setChecked(True)
        self.sound_cb.setToolTip("Play a chime when installation finishes.")
        bottom_zip.addWidget(self.sound_cb)

        test_snd = QtWidgets.QPushButton("▶")
        test_snd.setObjectName("small")
        test_snd.setFixedWidth(28)
        test_snd.setToolTip("Preview the chosen install sound")
        test_snd.clicked.connect(lambda: _play_sound())
        bottom_zip.addWidget(test_snd)

        choose_snd = QtWidgets.QPushButton("Choose Sound…")
        choose_snd.setObjectName("small")
        choose_snd.setToolTip("Pick which WAV plays when installation completes")
        choose_snd.clicked.connect(lambda: _choose_sound(self))
        bottom_zip.addWidget(choose_snd)

        bottom_zip.addStretch()

        self.install_btn = QtWidgets.QPushButton("Install Tools")
        self.setStyleSheet("QPushButton { font-weight: bold; font-size: 16px;}")
        self.install_btn.setObjectName("primary")
        icon_path = os.path.join(base_dir, "icons", "Install.png")
        self.install_btn.setIcon(QtGui.QIcon(icon_path))
        self.install_btn.setIconSize(QtCore.QSize(24, 24))
        self.install_btn.setEnabled(False)
        self.install_btn.clicked.connect(self._install)
        bottom_zip.addWidget(self.install_btn)

        outer.addLayout(bottom_zip)
        outer.addStretch()

    # ── Slots ──────────────────────────────────────────────────────────────────

    def _refresh_init_preview(self):
        if not hasattr(self, "write_init_cb"):
            return
        if not hasattr(self, "init_preview_lbl"):
            return

        if not self.write_init_cb.isChecked():
            self.init_preview_lbl.setText("(init.py registration disabled)")
            return

        example_path = "<install_dir>"

        dst = self.dst_edit.text().strip() if hasattr(self, "dst_edit") else ""
        if dst:
            example_path = dst.replace("\\", "/")

        ver   = self.nuke_ver_edit.currentText().strip() if hasattr(self, "nuke_ver_edit") else ""
        major = ver.split(".")[0] if ver else ""

        major_only = (
            self.major_only_toggle.isChecked()        # FIX: was major_only_cb
            if hasattr(self, "major_only_toggle")
            else False
        )

        if major_only and major.isdigit():
            preview = (
                f'if nuke.NUKE_VERSION_MAJOR == {major}:\n'
                f'    nuke.pluginAddPath(r"{example_path}")'
            )
        else:
            preview = f'nuke.pluginAddPath(r"{example_path}")'

        self.init_preview_lbl.setText(
            "Will write to ~/.nuke/init.py:\n\n" + preview
        )

    def _on_zip_changed(self, text):
        valid = os.path.isfile(text.strip())
        self.prev_btn.setEnabled(valid)
        self.install_btn.setEnabled(valid)
        self._refresh_init_preview()

    def _browse_zip(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self, "Select Tools Zip",
            os.path.expanduser('~'), "Zip Files (*.zip)"
        )
        if path:
            self.zip_edit.setText(path)

    def _browse_dst(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Install Directory", TOOLS_DIR
        )
        if path:
            self.dst_edit.setText(path)

    def _preview(self):
        path = self.zip_edit.text().strip()
        if not os.path.isfile(path):
            self.log.log("Select a valid .zip file first.", 'warn')
            return
        self.contents_tree.clear()
        try:
            entries = list_zip_contents(path)
            for e in entries:
                size_s  = f"{e['size'] / 1024:.1f} KB"
                comp_s  = f"{e['compress'] / 1024:.1f} KB"
                item = QtWidgets.QTreeWidgetItem(
                    [e['name'], size_s, comp_s, e['date']]
                )
                self.contents_tree.addTopLevelItem(item)
            self.file_count_lbl.setText(f"{len(entries)} file(s)")
            self.log.log(f"Preview: {len(entries)} files in archive.", 'ok')
        except Exception as ex:
            self.log.log(f"Preview failed: {ex}", 'error')

    def _remove_from_init(self):
        """Open picker dialog showing all init.py paths — user selects which to remove."""
        dlg = _InitPathPickerDialog(self)
        if not dlg.exec():
            return
        total = 0
        for path in dlg.result_paths:
            count, _ = _remove_from_init_py(path)
            total += count
            if count:
                self.log.log(f"Removed init.py entry: {path}", 'ok')
            else:
                self.log.log(f"Entry not found (already removed?): {path}", 'warn')
        if total:
            self.log.log(f"Total removed: {total} line(s) from init.py.", 'ok')
        self._refresh_init_preview()

    def _install(self):
        zip_path = self.zip_edit.text().strip()
        if not os.path.isfile(zip_path):
            self.log.log("Select a valid .zip file.", 'warn')
            return

        dst        = self.dst_edit.text().strip() or None
        overwrite  = self.overwrite_cb.isChecked()
        register   = self.register_cb.isChecked()
        write_init = self.write_init_cb.isChecked()
        nuke_ver   = self.nuke_ver_edit.currentText().strip()
        major_only = self.major_only_toggle.isChecked()   # FIX: was major_only_cb
        play_sound = self.sound_cb.isChecked()

        if write_init and not nuke_ver:
            self.log.log("Enter a Nuke version before writing to init.py.", 'warn')
            return

        self.install_btn.setEnabled(False)
        self.progress.setVisible(True)
        self.progress.setValue(0)

        def _progress_cb(current, total):
            pct = int(current / total * 100) if total else 100
            QtCore.QMetaObject.invokeMethod(
                self.progress, "setValue",
                Qt.QueuedConnection,
                QtCore.Q_ARG(int, pct)
            )

        def _run():
            _success = False
            try:
                name = os.path.splitext(os.path.basename(zip_path))[0]
                self.log.log(f"Installing '{name}' …")
                installed = install_from_zip(zip_path, dst, overwrite, _progress_cb)
                self.log.log(f"Installed → {installed}", 'ok')

                if register:
                    register_tool_path(installed)
                    self.log.log("Path registered with Nuke (live session).", 'ok')

                if write_init:
                    register_nuke_plugin_path(installed, nuke_ver, major_only)
                    scope = f"Nuke {nuke_ver.split('.')[0]} only" if major_only else "all versions"
                    self.log.log(
                        f"init.py updated  ({scope})  — {installed}", 'ok'
                    )

                _success = True

            except Exception as ex:
                self.log.log(f"Install failed: {ex}", 'error')
            finally:
                if play_sound and _success:
                    _play_sound()
                QtCore.QMetaObject.invokeMethod(
                    self.progress, "setVisible",
                    Qt.QueuedConnection, QtCore.Q_ARG(bool, False)
                )
                QtCore.QMetaObject.invokeMethod(
                    self.install_btn, "setEnabled",
                    Qt.QueuedConnection, QtCore.Q_ARG(bool, True)
                )

        threading.Thread(target=_run, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2  —  ZIP / EXPORT
# ══════════════════════════════════════════════════════════════════════════════

class ZipTab(QtWidgets.QWidget):
    def __init__(self, log: LogWidget, icon_dir, parent=None):
        super().__init__(parent)
        self.log = log
        self._ICON_DIR = icon_dir  # now properly defined
        self._build()

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(10)

        # ── Source folder ──────────────────────────────────────────────────────
        grp1 = QtWidgets.QGroupBox("Tools Folder to Zip")
        grp1.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; }")
        l1 = QtWidgets.QHBoxLayout(grp1)
        self.folder_edit = QtWidgets.QLineEdit()
        self.folder_edit.setPlaceholderText("Select a tools folder …")
        self.folder_edit.textChanged.connect(self._on_folder_changed)
        l1.addWidget(self.folder_edit)
        b1 = QtWidgets.QPushButton("Browse…")
        b1.setStyleSheet("QPushButton { font-weight: bold; font-size: 14px; }")
        b1.clicked.connect(self._browse_folder)
        l1.addWidget(b1)
        outer.addWidget(grp1)

        # ── Output path ────────────────────────────────────────────────────────
        grp2 = QtWidgets.QGroupBox("Output .zip File")
        grp2.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; }")
        l2 = QtWidgets.QHBoxLayout(grp2)
        self.out_edit = QtWidgets.QLineEdit()
        self.out_edit.setPlaceholderText(
            "Leave blank to auto-name next to source folder …"
        )
        l2.addWidget(self.out_edit)
        b2 = QtWidgets.QPushButton("Save As…")
        b2.setStyleSheet("QPushButton { font-weight: bold; font-size: 14px; }")
        b2.clicked.connect(self._browse_out)
        l2.addWidget(b2)
        outer.addWidget(grp2)

        # ── Extension filter ───────────────────────────────────────────────────
        grp3 = QtWidgets.QGroupBox("File Extension Filter")
        grp3.setStyleSheet("""
            QGroupBox {
                font-weight: bold; 
                font-size: 14px;
            }
            QLabel { 
                font-weight: bold; 
                font-size: 14px; 
            }
        """)
        l3 = QtWidgets.QVBoxLayout(grp3)
        label = QtWidgets.QLabel("Comma-separated (e.g. .py, .gizmo, .nk, .json) — leave blank to include ALL files")
        label.setWordWrap(True)
        l3.addWidget(label)
        self.ext_edit = QtWidgets.QLineEdit()
        self.ext_edit.setPlaceholderText(".py, .gizmo, .nk, .json, .png")
        l3.addWidget(self.ext_edit)
        outer.addWidget(grp3)

        # ── Preset buttons ─────────────────────────────────────────────────────
        grp4 = QtWidgets.QGroupBox("Quick Extension Presets")
        grp4.setStyleSheet("""
            QGroupBox {
                font-weight: bold;
                font-size: 14px;
                border: 1px solid #555;
                border-radius: 6px;
                margin-top: 8px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                subcontrol-position: top left;
                padding: 0 8px;
            }
        """)
        l4 = QtWidgets.QHBoxLayout(grp4)
        l4.setSpacing(8)

        # Load icons
        icon_path = python_icon = QtGui.QIcon(os.path.join(self._ICON_DIR, "icons", "Python Logos.png"))
        icon_path = nuke_icon   = QtGui.QIcon(os.path.join(self._ICON_DIR, "icons",  "Nuke + Python.png"))
        icon_path = all_icon    = QtGui.QIcon(os.path.join(self._ICON_DIR, "icons",  "all_icon.png"))
        icon_path = clear_icon  = QtGui.QIcon(os.path.join(self._ICON_DIR, "icons",  "clear_icon.png"))

        # Preset buttons with icons
        for label, exts, icon in [
            ("Python only",   ".py", python_icon),
            ("Nuke + Python", ".py, .nk, .gizmo", nuke_icon),
            ("All common",    ".py, .nk, .gizmo, .json, .png, .txt, .md", all_icon),
            ("Clear All",         "", clear_icon),
        ]:
            btn = QtWidgets.QPushButton(label)
            btn.setObjectName("small")
            _exts = exts
            btn.clicked.connect(lambda *_, e=_exts: self.ext_edit.setText(e))

            # Add icon if available
            if icon:
                btn.setIcon(icon)
                btn.setIconSize(QtCore.QSize(34, 34))

            # Bold text + padding
            btn.setStyleSheet("""
                QPushButton#small {
                    font-weight: bold;
                    font-size: 12px;
                    padding: 4px 10px;
                }
            """)

            l4.addWidget(btn)
        l4.addStretch()
        outer.addWidget(grp4)

        # ── Progress ───────────────────────────────────────────────────────────
        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 0)
        self.progress.setVisible(False)
        outer.addWidget(self.progress)

        # ── Zip button ─────────────────────────────────────────────────────────
        self.zip_btn = QtWidgets.QPushButton("Create Zip")
        self.zip_btn.setObjectName("primary")
        icon_path = os.path.join(self._ICON_DIR, "icons", "zip-file.png")
        self.zip_btn.setIcon(QtGui.QIcon(icon_path))
        self.zip_btn.setIconSize(QtCore.QSize(48, 48))
        self.zip_btn.setEnabled(False)
        self.zip_btn.clicked.connect(self._zip)
        outer.addWidget(self.zip_btn)

        outer.addStretch()

    # ── Event handlers ─────────────────────────────────────────────────────
    def _on_folder_changed(self, text):
        self.zip_btn.setEnabled(os.path.isdir(text.strip()))

    def _browse_folder(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Tools Folder"
        )
        if path:
            self.folder_edit.setText(path)

    def _browse_out(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self, "Save Zip As",
            os.path.expanduser('~'), "Zip Files (*.zip)"
        )
        if path:
            self.out_edit.setText(path)

    def _zip(self):
        folder = self.folder_edit.text().strip()
        if not os.path.isdir(folder):
            self.log.log("Select a valid folder first.", 'warn')
            return

        out  = self.out_edit.text().strip() or None
        raw  = self.ext_edit.text().strip()
        exts = [e.strip() for e in raw.split(',') if e.strip()] or None

        self.zip_btn.setEnabled(False)
        self.progress.setVisible(True)

        def _run():
            try:
                name = os.path.basename(folder.rstrip(os.sep))
                self.log.log(f"Zipping '{name}' …")
                result  = zip_folder(folder, out, exts)
                size_kb = os.path.getsize(result) / 1024
                self.log.log(f"Created: {result}  ({size_kb:.1f} KB)", 'ok')
            except Exception as ex:
                self.log.log(f"Zip failed: {ex}", 'error')
            finally:
                QtCore.QMetaObject.invokeMethod(
                    self.progress, "setVisible",
                    QtCore.Qt.QueuedConnection, QtCore.Q_ARG(bool, False)
                )
                QtCore.QMetaObject.invokeMethod(
                    self.zip_btn, "setEnabled",
                    QtCore.Qt.QueuedConnection, QtCore.Q_ARG(bool, True)
                )

        threading.Thread(target=_run, daemon=True).start()


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3  —  INSTALLED TOOLS
# ══════════════════════════════════════════════════════════════════════════════

class InstalledTab(QtWidgets.QWidget):
    def __init__(self, log: LogWidget, parent=None):
        super().__init__(parent)
        self.log = log
        self._build()

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(8)

        # ── Toolbar ────────────────────────────────────────────────────────────
        toolbar  = QtWidgets.QHBoxLayout()
        base_dir = os.path.dirname(__file__)

        self.refresh_btn = QtWidgets.QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh)
        icon_path = os.path.join(base_dir, "icons", "reload.png")
        self.refresh_btn.setIcon(QtGui.QIcon(icon_path))
        self.refresh_btn.setIconSize(QtCore.QSize(24, 24))
        toolbar.addWidget(self.refresh_btn)

        self.open_btn = QtWidgets.QPushButton("Open Folder")
        self.open_btn.setEnabled(False)
        icon_path = os.path.join(base_dir, "icons", "folder.png")
        self.open_btn.setIcon(QtGui.QIcon(icon_path))
        self.open_btn.setIconSize(QtCore.QSize(24, 24))
        self.open_btn.clicked.connect(self._open_folder)
        toolbar.addWidget(self.open_btn)

        self.register_btn = QtWidgets.QPushButton("Register in Nuke")
        icon_path = os.path.join(base_dir, "icons", "Registerd.png")
        self.register_btn.setIcon(QtGui.QIcon(icon_path))
        self.register_btn.setIconSize(QtCore.QSize(24, 24))
        self.register_btn.setEnabled(False)
        self.register_btn.clicked.connect(self._register_selected)
        toolbar.addWidget(self.register_btn)

        toolbar.addStretch()

        self.uninstall_btn = QtWidgets.QPushButton("Uninstall")
        self.uninstall_btn.setObjectName("danger")
        self.uninstall_btn.setEnabled(False)
        icon_path = os.path.join(base_dir, "icons", "delete.png")
        self.uninstall_btn.setIcon(QtGui.QIcon(icon_path))
        self.uninstall_btn.setIconSize(QtCore.QSize(24, 24))
        self.uninstall_btn.clicked.connect(self._uninstall)
        toolbar.addWidget(self.uninstall_btn)

        outer.addLayout(toolbar)

        # ── Tree ───────────────────────────────────────────────────────────────
        self.tree = QtWidgets.QTreeWidget()
        self.tree.setHeaderLabels(['Tool Name', 'Files', 'Install Path', 'Installed At'])
        self.tree.setStyleSheet(" font-weight: bold; font-size: 14px; ")
        self.tree.setColumnWidth(0, 140)
        self.tree.setColumnWidth(1,  50)
        self.tree.setColumnWidth(2, 280)
        self.tree.setAlternatingRowColors(True)
        self.tree.itemSelectionChanged.connect(self._on_selection)
        outer.addWidget(self.tree, 1)

        # ── Summary label ──────────────────────────────────────────────────────
        self.summary_lbl = QtWidgets.QLabel("")
        self.summary_lbl.setStyleSheet("color:#888; font-size:11px;")
        outer.addWidget(self.summary_lbl)

        self.refresh()

    # ── Logic ──────────────────────────────────────────────────────────────────

    def refresh(self):
        self.tree.clear()
        tools = get_installed_tools()
        for name, info in tools.items():
            fc   = info.get('file_count', len(info.get('files', [])))
            item = QtWidgets.QTreeWidgetItem([
                name,
                str(fc),
                info.get('install_dir', ''),
                info.get('installed_at', '')[:19],
            ])
            item.setToolTip(2, info.get('install_dir', ''))
            for f in info.get('files', []):
                if os.path.basename(f).lower() == 'manifest.json':
                    continue
                child = QtWidgets.QTreeWidgetItem(['', '', f, ''])
                child.setForeground(2, QColor('#777'))
                item.addChild(child)
            self.tree.addTopLevelItem(item)

        count = len(tools)
        self.summary_lbl.setText(f"{count} tool(s) installed   |   manifest: {TOOLS_DIR}")
        self._on_selection()
        self.log.log(f"{count} installed tool(s).", 'ok')

    def _selected_tool(self):
        """Return (name, info) of the top-level selected item, or (None, None)."""
        sel = self.tree.selectedItems()
        if not sel:
            return None, None
        item = sel[0]
        while item.parent():
            item = item.parent()
        name = item.text(0)
        return name, get_installed_tools().get(name, {})

    def _on_selection(self):
        name, _ = self._selected_tool()
        has = name is not None
        self.open_btn.setEnabled(has)
        self.register_btn.setEnabled(has)
        self.uninstall_btn.setEnabled(has)

    def _open_folder(self):
        _, info = self._selected_tool()
        path = info.get('install_dir', '')
        if os.path.isdir(path):
            QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(path))
        else:
            self.log.log(f"Directory not found: {path}", 'warn')

    def _register_selected(self):
        _, info = self._selected_tool()
        path = info.get('install_dir', '')
        if path:
            register_tool_path(path)
            self.log.log(f"Registered: {path}", 'ok')
        else:
            self.log.log("No install path found.", 'warn')

    def _uninstall(self):
        name, info = self._selected_tool()
        if not name:
            return
        reply = QtWidgets.QMessageBox.question(
            self, "Confirm Uninstall",
            f"Remove tool '{name}' and delete:\n{info.get('install_dir', '')}",
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
        )
        if reply == QtWidgets.QMessageBox.Yes:
            ok = uninstall_tool(name)
            if ok:
                self.log.log(f"Uninstalled: {name}", 'ok')
            else:
                self.log.log(f"'{name}' not in manifest.", 'warn')
            self.refresh()


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4  —  NUKE UTILITIES
# ══════════════════════════════════════════════════════════════════════════════

class NukeTab(QtWidgets.QWidget):
    def __init__(self, log: LogWidget, parent=None):
        super().__init__(parent)
        self.log = log
        self._build()

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(12, 12, 12, 12)
        outer.setSpacing(10)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        inner_w = QtWidgets.QWidget()
        inner   = QtWidgets.QVBoxLayout(inner_w)
        inner.setSpacing(10)
        scroll.setWidget(inner_w)
        outer.addWidget(scroll)

        # ── Node Finder ───────────────────────────────────────────────────────
        grp_find = QtWidgets.QGroupBox("Node Finder / Selector")
        grp_find.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; background-color: #2e2e2e; }")
        grp_find.setStyleSheet("font-weight: bold; font-size: 10px;")
        find_grid = QtWidgets.QGridLayout(grp_find)

        find_grid.addWidget(QtWidgets.QLabel("Name / pattern:"), 0, 0)
        self.node_name = QtWidgets.QLineEdit()
        self.node_name.setPlaceholderText("e.g.  Grade1  or  Grade  (partial match)")
        find_grid.addWidget(self.node_name, 0, 1)

        find_grid.addWidget(QtWidgets.QLabel("Node class:"), 1, 0)
        self.node_class = QtWidgets.QLineEdit()
        self.node_class.setPlaceholderText("e.g.  Grade  or  Merge2  (leave blank = any)")
        find_grid.addWidget(self.node_class, 1, 1)

        find_btn = QtWidgets.QPushButton("Find & Select")
        find_btn.setObjectName("primary")
        find_btn.clicked.connect(self._find_nodes)
        find_grid.addWidget(find_btn, 2, 0, 1, 2)
        inner.addWidget(grp_find)

        # ── Batch Operations ─────────────────────────────────────────────────
        grp_batch = QtWidgets.QGroupBox("Batch Node Operations")
        grp_batch.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; background-color: #2e2e2e;  }")
        # grp_batch.setStyleSheet("font-weight: bold; font-size: 14px;")
        batch_grid = QtWidgets.QGridLayout(grp_batch)

        ops = [
            ("Select All",        self._select_all,            0, 0),
            ("Deselect All",      self._deselect_all,          0, 1),
            ("Select Viewers",    self._select_viewers,        0, 2),
            ("Delete Selected",   self._delete_selected,       1, 0),
            ("Disable Selected",  lambda: self._set_disable(True),  1, 1),
            ("Enable Selected",   lambda: self._set_disable(False), 1, 2),
            ("Zoom to Selected",  self._zoom_selected,         2, 0),
            ("Copy to Clipboard", self._copy_selected,         2, 1),
        ]
        for label, slot, row, col in ops:
            btn = QtWidgets.QPushButton(label)
            btn.clicked.connect(slot)
            batch_grid.addWidget(btn, row, col)
        inner.addWidget(grp_batch)

        # ── Knob Setter ───────────────────────────────────────────────────────
        grp_knob = QtWidgets.QGroupBox("Set Knob on Selected Nodes")
        grp_knob.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; background-color: #2e2e2e;  }")
        # grp_knob.setStyleSheet("font-weight: bold; font-size: 14px;")
        knob_grid = QtWidgets.QGridLayout(grp_knob)

        knob_grid.addWidget(QtWidgets.QLabel("Knob name:"), 0, 0)
        self.knob_name = QtWidgets.QLineEdit()
        self.knob_name.setPlaceholderText("e.g.  label   disable   postage_stamp")
        knob_grid.addWidget(self.knob_name, 0, 1)

        knob_grid.addWidget(QtWidgets.QLabel("Value:"), 1, 0)
        self.knob_value = QtWidgets.QLineEdit()
        self.knob_value.setPlaceholderText("string or numeric value")
        knob_grid.addWidget(self.knob_value, 1, 1)

        knob_apply = QtWidgets.QPushButton("Apply to Selected")
        knob_apply.setObjectName("primary")
        knob_apply.clicked.connect(self._set_knob)
        knob_grid.addWidget(knob_apply, 2, 0, 1, 2)
        inner.addWidget(grp_knob)

        # ── Script Info ───────────────────────────────────────────────────────
        grp_info = QtWidgets.QGroupBox("Script Info")
        grp_info.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; background-color: #2e2e2e;  }")
        # grp_info.setStyleSheet("font-weight: bold; font-size: 14px;")
        info_l = QtWidgets.QVBoxLayout(grp_info)
        self.info_display = QtWidgets.QTextEdit()
        self.info_display.setReadOnly(True)
        self.info_display.setFont(QFont("Courier New", 10))
        self.info_display.setMaximumHeight(130)
        info_l.addWidget(self.info_display)
        refresh_info = QtWidgets.QPushButton("Refresh Info")
        refresh_info.clicked.connect(self._refresh_info)
        info_l.addWidget(refresh_info)
        inner.addWidget(grp_info)

        # ── Node Creator ──────────────────────────────────────────────────────
        grp_create = QtWidgets.QGroupBox("Create Node")
        grp_create.setStyleSheet("QGroupBox { font-weight: bold; font-size: 14px; background-color: #2e2e2e;  }")
        # grp_create.setStyleSheet("font-weight: bold; font-size: 14px;")
        create_l = QtWidgets.QGridLayout(grp_create)

        create_l.addWidget(QtWidgets.QLabel("Node class:"), 0, 0)
        self.create_class = QtWidgets.QLineEdit()
        self.create_class.setPlaceholderText("e.g.  Grade   Merge2   Roto")
        create_l.addWidget(self.create_class, 0, 1)

        create_l.addWidget(QtWidgets.QLabel("Name (optional):"), 1, 0)
        self.create_name = QtWidgets.QLineEdit()
        self.create_name.setPlaceholderText("Leave blank for default name")
        create_l.addWidget(self.create_name, 1, 1)

        create_btn = QtWidgets.QPushButton("Create Node")
        create_btn.setObjectName("primary")
        create_btn.clicked.connect(self._create_node)
        create_l.addWidget(create_btn, 2, 0, 1, 2)
        inner.addWidget(grp_create)

        inner.addStretch()

    # ── Nuke helpers ───────────────────────────────────────────────────────────

    def _nuke(self, fn):
        """Run fn(nuke) safely; warn if outside Nuke."""
        try:
            import nuke
            return fn(nuke)
        except ImportError:
            self.log.log("Nuke is not available (running outside Nuke).", 'warn')
        except Exception as ex:
            self.log.log(f"✘  {ex}", 'error')
        return None

    # ── Slots ──────────────────────────────────────────────────────────────────

    def _find_nodes(self):
        name_pat  = self.node_name.text().strip().lower()
        class_pat = self.node_class.text().strip().lower()

        def op(nuke):
            nuke.selectAll()
            nuke.invertSelection()
            found = []
            for n in nuke.allNodes():
                name_match  = (not name_pat)  or (name_pat  in n.name().lower())
                class_match = (not class_pat) or (class_pat in n.Class().lower())
                if name_match and class_match:
                    n.setSelected(True)
                    found.append(f"{n.name()} [{n.Class()}]")
            if found:
                self.log.log(f"Selected {len(found)}: {', '.join(found[:6])}"
                             + ("…" if len(found) > 6 else ""), 'ok')
            else:
                self.log.log("No matching nodes found.", 'warn')

        self._nuke(op)

    def _select_all(self):
        self._nuke(lambda nuke: nuke.selectAll())
        self.log.log("All nodes selected.", 'ok')

    def _deselect_all(self):
        def op(nuke):
            nuke.selectAll()
            nuke.invertSelection()
        self._nuke(op)
        self.log.log("All nodes deselected.", 'ok')

    def _select_viewers(self):
        def op(nuke):
            nuke.selectAll()
            nuke.invertSelection()
            for n in nuke.allNodes('Viewer'):
                n.setSelected(True)
            count = len(nuke.selectedNodes())
            self.log.log(f"{count} Viewer(s) selected.", 'ok')
        self._nuke(op)

    def _delete_selected(self):
        def op(nuke):
            sel = nuke.selectedNodes()
            if not sel:
                self.log.log("Nothing selected.", 'warn')
                return
            reply = QtWidgets.QMessageBox.question(
                self, "Confirm Delete",
                f"Delete {len(sel)} selected node(s)?",
                QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No
            )
            if reply == QtWidgets.QMessageBox.Yes:
                for n in sel:
                    nuke.delete(n)
                self.log.log(f"Deleted {len(sel)} node(s).", 'ok')
        self._nuke(op)

    def _set_disable(self, state):
        def op(nuke):
            nodes = nuke.selectedNodes()
            count = 0
            for n in nodes:
                try:
                    n['disable'].setValue(state)
                    count += 1
                except Exception:
                    pass
            verb = "Disabled" if state else "Enabled"
            self.log.log(f"{verb} {count} node(s).", 'ok')
        self._nuke(op)

    def _zoom_selected(self):
        def op(nuke):
            nuke.zoomToFitSelected()
            self.log.log("Zoomed to selected.", 'ok')
        self._nuke(op)

    def _copy_selected(self):
        def op(nuke):
            nuke.nodeCopy('%clipboard%')
            count = len(nuke.selectedNodes())
            self.log.log(f"Copied {count} node(s) to clipboard.", 'ok')
        self._nuke(op)

    def _set_knob(self):
        knob  = self.knob_name.text().strip()
        value = self.knob_value.text().strip()
        if not knob:
            self.log.log("Enter a knob name.", 'warn')
            return

        def op(nuke):
            nodes = nuke.selectedNodes()
            if not nodes:
                self.log.log("No nodes selected.", 'warn')
                return
            count = 0
            for n in nodes:
                try:
                    k = n[knob]
                    try:
                        k.setValue(float(value))
                    except (ValueError, TypeError):
                        k.setValue(value)
                    count += 1
                except Exception:
                    pass
            self.log.log(f"Set '{knob}' = '{value}' on {count}/{len(nodes)} node(s).", 'ok')
        self._nuke(op)

    def _refresh_info(self):
        def op(nuke):
            r      = nuke.root()
            script = r.name() or "(unsaved)"
            fps    = r['fps'].value()
            first  = int(r['first_frame'].value())
            last   = int(r['last_frame'].value())
            all_n  = nuke.allNodes()
            sel_n  = nuke.selectedNodes()
            classes = {}
            for n in all_n:
                c = n.Class()
                classes[c] = classes.get(c, 0) + 1
            top5 = sorted(classes.items(), key=lambda x: -x[1])[:5]
            top5_str = ', '.join(f"{c}×{cnt}" for c, cnt in top5)
            text = (
                f"Script:       {script}\n"
                f"FPS:          {fps}\n"
                f"Frame range:  {first} – {last}  ({last - first + 1} frames)\n"
                f"Total nodes:  {len(all_n)}\n"
                f"Selected:     {len(sel_n)}\n"
                f"Top classes:  {top5_str}"
            )
            self.info_display.setText(text)
            self.log.log("Script info refreshed.", 'ok')
        self._nuke(op)

    def _create_node(self):
        cls  = self.create_class.text().strip()
        name = self.create_name.text().strip()
        if not cls:
            self.log.log("Enter a node class.", 'warn')
            return

        def op(nuke):
            n = nuke.createNode(cls)
            if name:
                n.setName(name)
            self.log.log(f"Created: {n.name()} [{cls}]", 'ok')
        self._nuke(op)


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5  —  ABOUT
# ══════════════════════════════════════════════════════════════════════════════

class AboutTab(QtWidgets.QWidget):
    """About page — app info, GitHub repo, LinkedIn contact."""

    # ── Edit these constants to personalise the tab ───────────────────────────
    APP_VERSION   = "1.0.0"
    AUTHOR        = "Author Nitin Kashyap"
    ROLE          = "Junior VFX Compositor"
    LOGO_ARTIST   = "SaiKrishna Sallagari"
    GITHUB_URL    = "https://github.com/Nitinkashyap96"
    LINKEDIN_URL  = "https://www.linkedin.com/in/nitin-kashyap-8541213a6/"
    DESCRIPTION   = (
        "Nuke Tools Manager is a PySide2 / PySide6 GUI for installing, "
        "packaging, and managing custom Nuke tools and plug-ins.\n\n"
        "Install from folders or .zip archives, register paths in "
        "~/.nuke/init.py with per-version scoping, browse installed tools, "
        "and run common Nuke node operations — all from one window."
    )

    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()

    def _build(self):
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── Scroll area so it's safe on small screens ─────────────────────────
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)
        inner_w = QtWidgets.QWidget()
        inner   = QtWidgets.QVBoxLayout(inner_w)
        inner.setContentsMargins(32, 28, 32, 28)
        inner.setSpacing(0)
        scroll.setWidget(inner_w)
        outer.addWidget(scroll)

        # ── Hero: logo + app name + version ───────────────────────────────────
        hero = QtWidgets.QHBoxLayout()
        hero.setSpacing(24)

        base_dir  = os.path.dirname(os.path.abspath(__file__))
        logo_path = os.path.join(base_dir, "icon_256.png")
        logo_lbl  = QtWidgets.QLabel()
        if os.path.isfile(logo_path):
            pix = QtGui.QPixmap(logo_path).scaled(
                96, 96, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            logo_lbl.setPixmap(pix)
        logo_lbl.setFixedSize(96, 96)
        logo_lbl.setAlignment(Qt.AlignCenter)
        hero.addWidget(logo_lbl)

        name_col = QtWidgets.QVBoxLayout()
        name_col.setSpacing(4)
        name_col.setAlignment(Qt.AlignVCenter)

        app_lbl = QtWidgets.QLabel("NK Tools Manager")
        app_lbl.setStyleSheet("""
            font-size: 26px;
            font-weight: bold;
            color: #f0a500;
            letter-spacing: 1px;
        """)
        name_col.addWidget(app_lbl)

        sub_row = QtWidgets.QHBoxLayout()
        sub_row.setSpacing(10)
        ver_lbl = QtWidgets.QLabel(f"v{self.APP_VERSION}")
        ver_lbl.setStyleSheet("""
            font-size: 12px;
            color: #888;
            background: #2a2a2a;
            border: 1px solid #444;
            border-radius: 3px;
            padding: 2px 8px;
        """)
        sub_row.addWidget(ver_lbl)
        sub_row.addWidget(QtWidgets.QLabel(f"by  {self.AUTHOR}"))
        sub_row.addStretch()
        name_col.addLayout(sub_row)

        role_lbl = QtWidgets.QLabel(self.ROLE)
        role_lbl.setStyleSheet("font-size:12px; color:#f0a500; font-style:italic;")
        name_col.addWidget(role_lbl)

        hero.addLayout(name_col)
        hero.addStretch()
        inner.addLayout(hero)
        inner.addSpacing(20)

        # ── Divider ───────────────────────────────────────────────────────────
        div1 = QtWidgets.QFrame()
        div1.setFrameShape(QtWidgets.QFrame.HLine)
        div1.setStyleSheet("color: #3a3a3a;")
        inner.addWidget(div1)
        inner.addSpacing(18)

        # ── Description ───────────────────────────────────────────────────────
        desc_lbl = QtWidgets.QLabel(self.DESCRIPTION)
        desc_lbl.setWordWrap(True)
        desc_lbl.setStyleSheet("""
            font-size: 13px;
            color: #c0c0c0;
            line-height: 1.6;
        """)
        inner.addWidget(desc_lbl)
        inner.addSpacing(28)

        # ── Links group ───────────────────────────────────────────────────────
        grp_links = QtWidgets.QGroupBox("Links")
        grp_links.setStyleSheet("""
            QGroupBox {
                font-size: 13px;
                font-weight: bold;
                color: #aaa;
                border: 1px solid #3a3a3a;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 14px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px;
            }
        """)
        links_l = QtWidgets.QVBoxLayout(grp_links)
        links_l.setSpacing(10)

        # GitHub row
        gh_row = QtWidgets.QHBoxLayout()
        _gh_logo_path = os.path.join(base_dir, "icons", "GitHub.png")
        gh_icon = QtWidgets.QLabel()
        gh_icon.setFixedSize(36, 36)
        if os.path.isfile(_gh_logo_path):
            _gh_pix = QtGui.QPixmap(_gh_logo_path).scaled(
                36, 36, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            gh_icon.setPixmap(_gh_pix)
        else:
            gh_icon.setText("⌥")
            gh_icon.setStyleSheet("font-size:18px; color:#e0e0e0;")

        gh_col = QtWidgets.QVBoxLayout()
        gh_col.setSpacing(2)
        gh_title = QtWidgets.QLabel("GitHub Repository")
        gh_title.setStyleSheet("font-weight:bold; color:#d0d0d0; font-size:13px;")
        gh_sub   = QtWidgets.QLabel("Source code, issues &amp; releases")
        gh_sub.setStyleSheet("color:#888; font-size:11px;")
        gh_col.addWidget(gh_title)
        gh_col.addWidget(gh_sub)

        gh_btn = QtWidgets.QPushButton("Open on GitHub")
        gh_btn.setFixedWidth(160)
        gh_btn.setStyleSheet("""
            QPushButton {
                background: #1a1a1a;
                border: 1px solid #555;
                border-radius: 4px;
                color: #d0d0d0;
                padding: 5px 14px;
                font-size: 12px;
            }
            QPushButton:hover {
                border-color: #f0a500;
                color: #f0a500;
            }
        """)
        gh_btn.setCursor(Qt.PointingHandCursor)
        _gh_icon_path = os.path.join(base_dir, 'icons', 'GitHub.png')
        if os.path.isfile(_gh_icon_path):
            gh_btn.setIcon(QtGui.QIcon(_gh_icon_path))
            gh_btn.setIconSize(QtCore.QSize(20, 20))
        _gh_url = self.GITHUB_URL
        gh_btn.clicked.connect(lambda: QDesktopServices.openUrl(
            QtCore.QUrl(_gh_url)
        ))

        gh_row.addWidget(gh_icon)
        gh_row.addLayout(gh_col)
        gh_row.addStretch()
        gh_row.addWidget(gh_btn)
        links_l.addLayout(gh_row)

        # Separator
        sep1 = QtWidgets.QFrame()
        sep1.setFrameShape(QtWidgets.QFrame.HLine)
        sep1.setStyleSheet("color: #333;")
        links_l.addWidget(sep1)

        # LinkedIn row
        li_row = QtWidgets.QHBoxLayout()
        li_icon = QtWidgets.QLabel("in")
        li_icon.setFixedWidth(28)
        li_icon.setStyleSheet("""
            font-size: 14px;
            font-weight: bold;
            color: #0a66c2;
            background: #0a66c2;
            color: white;
            border-radius: 4px;
            padding: 2px 5px;
        """)
        li_icon.setAlignment(Qt.AlignCenter)

        li_col = QtWidgets.QVBoxLayout()
        li_col.setSpacing(2)
        li_title = QtWidgets.QLabel("Connect on LinkedIn")
        li_title.setStyleSheet("font-weight:bold; color:#d0d0d0; font-size:13px;")
        li_sub   = QtWidgets.QLabel("Questions, collaborations &amp; feedback")
        li_sub.setStyleSheet("color:#888; font-size:11px;")
        li_col.addWidget(li_title)
        li_col.addWidget(li_sub)

        li_btn = QtWidgets.QPushButton("View Profile")
        li_btn.setFixedWidth(160)
        li_btn.setStyleSheet("""
            QPushButton {
                background: #1a1a1a;
                border: 1px solid #555;
                border-radius: 4px;
                color: #d0d0d0;
                padding: 5px 14px;
                font-size: 12px;
            }
            QPushButton:hover {
                border-color: #0a66c2;
                color: #4da3ff;
            }
        """)
        li_btn.setCursor(Qt.PointingHandCursor)
        _li_url = self.LINKEDIN_URL
        li_btn.clicked.connect(lambda: QDesktopServices.openUrl(
            QtCore.QUrl(_li_url)
        ))

        li_row.addWidget(li_icon)
        li_row.addLayout(li_col)
        li_row.addStretch()
        li_row.addWidget(li_btn)
        links_l.addLayout(li_row)

        inner.addWidget(grp_links)
        inner.addSpacing(24)

        # ── Feature highlights ────────────────────────────────────────────────
        grp_feat = QtWidgets.QGroupBox("Features")
        grp_feat.setStyleSheet("""
            QGroupBox {
                font-size: 13px;
                font-weight: bold;
                color: #aaa;
                border: 1px solid #3a3a3a;
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 14px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 12px;
                padding: 0 6px;
            }
        """)
        feat_l = QtWidgets.QVBoxLayout(grp_feat)
        feat_l.setSpacing(6)

        features = [
            ("📁", "Install Folder",     "Install tool folders directly — no zip required"),
            ("🗜",  "Install Zip",        "Install from .zip archives with content preview"),
            ("📦", "Zip / Export",       "Package tool folders with extension filters"),
            ("🔧", "Installed Tools",    "Browse, register, and uninstall managed tools"),
            ("⚙",  "Nuke Utils",        "Node finder, batch ops, knob setter, script info"),
            ("📝", "init.py Writer",     "Persistent per-version nuke.pluginAddPath() registration"),
        ]
        for emoji, title, detail in features:
            row = QtWidgets.QHBoxLayout()
            row.setSpacing(10)
            em_lbl = QtWidgets.QLabel(emoji)
            em_lbl.setFixedWidth(28)
            em_lbl.setStyleSheet("font-size: 16px;")
            title_lbl = QtWidgets.QLabel(f"<b>{title}</b>  <span style='color:#888;font-size:11px;'>{detail}</span>")
            title_lbl.setStyleSheet("font-size: 12px; color: #c0c0c0;")
            row.addWidget(em_lbl)
            row.addWidget(title_lbl)
            row.addStretch()
            feat_l.addLayout(row)

        inner.addWidget(grp_feat)
        inner.addSpacing(28)

        # ── LOGO ARTIST SECTION (NEW) ────────────────────────────
        # grp_logo = QtWidgets.QGroupBox("Credit Logo Artist")
        # grp_logo.setStyleSheet(grp_links.styleSheet())
        # logo_l = QtWidgets.QVBoxLayout(grp_logo)

        # logo_name = QtWidgets.QLabel(self.LOGO_ARTIST)
        # logo_name.setStyleSheet("""
        #     font-size: 16px;
        #     font-weight: bold;
        #     color: #f0a500;
        # """)

        # logo_sub = QtWidgets.QLabel("------")
        # logo_sub.setStyleSheet("color:#888; font-size:14px;")

        # logo_l.addWidget(logo_name)
        # logo_l.addWidget(logo_sub)

        # inner.addWidget(grp_logo)
        # inner.addSpacing(28)

        # ── LOGO ARTIST SECTION (REFINED) ────────────────────────────
        grp_logo = QtWidgets.QGroupBox("Credit Logo Artist")
        grp_logo.setStyleSheet(grp_links.styleSheet())
        logo_l = QtWidgets.QVBoxLayout(grp_logo)
        logo_l.setSpacing(2) 

        # Artist Name
        logo_name = QtWidgets.QLabel(self.LOGO_ARTIST)
        logo_name.setStyleSheet("""
            font-size: 16px;
            font-weight: bold;
            color: #f0a500;
        """)

        # Artist Subtitle / Role
        logo_sub = QtWidgets.QLabel("Figma UI Design")
        logo_sub.setStyleSheet("color: #999; font-size: 13px; font-style: italic;")

        logo_l.addWidget(logo_name)
        logo_l.addWidget(logo_sub)

        inner.addWidget(grp_logo)
        inner.addSpacing(28)

        # ── License / footer ──────────────────────────────────────────────────
        footer_text = f"© {self.AUTHOR} ({self.ROLE})  •  MIT License  •  Built with PySide2 / PySide6"
        footer = QtWidgets.QLabel(footer_text)
        footer.setAlignment(QtCore.Qt.AlignCenter)

        # Added the missing colon and adjusted font-size for a professional look
        footer.setStyleSheet("""
            color: white; 
            font-size: 12px; 
            font-weight: normal;
            margin-top: 10px;
            opacity: 0.7;
        """)

        inner.addWidget(footer)
        inner.addStretch()

# ══════════════════════════════════════════════════════════════════════════════
# SETTINGS TAB
# ══════════════════════════════════════════════════════════════════════════════

class SettingsTab(QtWidgets.QWidget):
    """Settings — Theme picker (live), General, Sound, Splash, Reset."""

    def __init__(self, parent=None):
        super().__init__(parent)
        import json as _json
        self._json = _json
        self._cfg_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "setting_tip", "settings.cfg"
        )
        self._cfg = self._load_cfg()
        self._build()

    # ── Config ────────────────────────────────────────────────────────────────
    def _load_cfg(self):
        if os.path.isfile(self._cfg_path):
            try:
                with open(self._cfg_path, "r", encoding="utf-8") as fh:
                    return self._json.load(fh)
            except Exception:
                pass
        return {}

    def _save_cfg(self):
        try:
            with open(self._cfg_path, "w", encoding="utf-8") as fh:
                self._json.dump(self._cfg, fh, indent=2)
        except Exception:
            pass

    def get(self, key, default=None):
        return self._cfg.get(key, default)

    def _set(self, key, value):
        self._cfg[key] = value
        self._save_cfg()

    # ── Layout helpers ────────────────────────────────────────────────────────
    def _section(self, title):
        grp = QtWidgets.QGroupBox(title)
        vl  = QtWidgets.QVBoxLayout(grp)
        vl.setContentsMargins(14, 20, 14, 14)
        vl.setSpacing(10)
        return grp, vl

    def _row(self, label, widget, lw=210, tip=""):
        h = QtWidgets.QHBoxLayout()
        h.setSpacing(10)
        lbl = QtWidgets.QLabel(label)
        lbl.setFixedWidth(lw)
        if tip:
            lbl.setToolTip(tip)
            widget.setToolTip(tip)
        h.addWidget(lbl)
        h.addWidget(widget, 1)
        return h

    # ── Build ─────────────────────────────────────────────────────────────────
    def _build(self):
        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QtWidgets.QFrame.NoFrame)

        inner  = QtWidgets.QWidget()
        lay    = QtWidgets.QVBoxLayout(inner)
        lay.setContentsMargins(20, 16, 20, 20)
        lay.setSpacing(14)
        scroll.setWidget(inner)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(scroll)

        # ──Theme ──────────────────────────────────────────────────────────
        grp_th, vl_th = self._section("Theme")
        grp_th.setStyleSheet(" color white; font-weight: bold; font-size: 16px ")

        hint = QtWidgets.QLabel(
            "Select a theme — applies instantly to the entire window."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#888; font-size:11px;")
        vl_th.addWidget(hint)

        self._theme_btns = {}
        current = self.get("theme", _DEFAULT_THEME)

        grid = QtWidgets.QGridLayout()
        grid.setSpacing(8)
        grid.setContentsMargins(0, 4, 0, 4)

        for idx, (name, colors) in enumerate(THEMES.items()):
            acc    = colors["acc"]
            bg     = colors["bg_base"]
            bgw    = colors["bg_win"]
            txt    = colors["txt"]
            brd    = colors["brd"]

            btn = QtWidgets.QPushButton(name)
            btn.setCheckable(True)
            btn.setChecked(name == current)
            btn.setMinimumHeight(54)
            btn.setMinimumWidth(155)
            btn.setStyleSheet("""
                QPushButton {{
                    background: {bg};
                    color: {txt};
                    border: 2px solid {brd};
                    border-radius: 6px;
                    font-size: 12px;
                    font-weight: bold;
                    padding: 4px 10px;
                    text-align: left;
                }}
                QPushButton:hover {{
                    border-color: {acc};
                }}
                QPushButton:checked {{
                    border: 3px solid {acc};
                    background: {bgw};
                    color: {acc};
                }}
            """.format(bg=bg, txt=txt, brd=brd, bgw=bgw, acc=acc))

            # colour-strip painted as a child frame
            strip = QtWidgets.QFrame(btn)
            strip.setStyleSheet(
                "background: {}; border-radius: 2px;".format(acc)
            )
            strip.setFixedHeight(5)
            strip.lower()

            def _reposition(event, b=btn, s=strip):
                s.setFixedWidth(b.width() - 16)
                s.move(8, b.height() - 10)

            btn.resizeEvent = _reposition

            btn.clicked.connect(lambda *_, n=name: self._apply_theme(n))
            self._theme_btns[name] = btn

            row_i, col_i = divmod(idx, 4)
            grid.addWidget(btn, row_i, col_i)

        vl_th.addLayout(grid)
        lay.addWidget(grp_th)

        # ──General ─────────────────────────────────────────────────────────
        grp_gen, vl_gen = self._section("General")
        grp_gen.setStyleSheet("color:white; font-size: 12px;")

        self.nuke_ver_edit = QtWidgets.QLineEdit(
            self.get("default_nuke_version", "")
        )
        self.nuke_ver_edit.setPlaceholderText("e.g. 15  (blank = all versions)")
        self.nuke_ver_edit.editingFinished.connect(
            lambda: self._set("default_nuke_version",
                              self.nuke_ver_edit.text().strip())
        )
        vl_gen.addLayout(self._row(
            "Default Nuke Version", self.nuke_ver_edit,
            tip="Pre-fills the Nuke version field on Install tabs"
        ))

        self.tools_dir_edit = QtWidgets.QLineEdit(
            self.get("default_tools_dir", "")
        )
        self.tools_dir_edit.setPlaceholderText("e.g. C:/Users/Name/.nuke")
        self.tools_dir_edit.editingFinished.connect(
            lambda: self._set("default_tools_dir",
                              self.tools_dir_edit.text().strip())
        )
        browse_btn = QtWidgets.QPushButton("Browse…")
        browse_btn.setFixedWidth(80)
        browse_btn.clicked.connect(self._browse_tools_dir)

        dir_h = QtWidgets.QHBoxLayout()
        dir_h.setSpacing(8)
        dl = QtWidgets.QLabel("Default Tools Dir")
        dl.setFixedWidth(210)
        dir_h.addWidget(dl)
        dir_h.addWidget(self.tools_dir_edit, 1)
        dir_h.addWidget(browse_btn)
        vl_gen.addLayout(dir_h)

        self.write_init_cb = QtWidgets.QCheckBox("Write to init.py by default")
        self.write_init_cb.setChecked(self.get("write_init_default", True))
        self.write_init_cb.toggled.connect(
            lambda v: self._set("write_init_default", v))
        vl_gen.addWidget(self.write_init_cb)

        self.overwrite_cb = QtWidgets.QCheckBox(
            "Overwrite existing tools by default")
        self.overwrite_cb.setChecked(self.get("overwrite_default", False))
        self.overwrite_cb.toggled.connect(
            lambda v: self._set("overwrite_default", v))
        vl_gen.addWidget(self.overwrite_cb)

        lay.addWidget(grp_gen)

        # ──Sound ──────────────────────────────────────────────────────────
        grp_snd, vl_snd = self._section("Sound")
        grp_snd.setStyleSheet("color:white; font-size: 12px;")

        self.sound_enable_cb = QtWidgets.QCheckBox(
            "Enable install complete sound")
        self.sound_enable_cb.setChecked(self.get("sound_enabled", True))
        self.sound_enable_cb.toggled.connect(
            lambda v: self._set("sound_enabled", v))
        vl_snd.addWidget(self.sound_enable_cb)

        self.snd_lbl = QtWidgets.QLabel("—")
        self._refresh_snd_lbl()

        prev_btn = QtWidgets.QPushButton("▶")
        prev_btn.setFixedWidth(34)
        prev_btn.setToolTip("Preview chosen sound")
        prev_btn.clicked.connect(self._preview_sound)

        choose_btn = QtWidgets.QPushButton("Choose Sound…")
        choose_btn.setToolTip("Pick which WAV plays on install complete")
        choose_btn.clicked.connect(self._choose_sound)

        snd_h = QtWidgets.QHBoxLayout()
        snd_h.setSpacing(6)
        sl = QtWidgets.QLabel("Install Sound")
        sl.setFixedWidth(210)
        snd_h.addWidget(sl)
        snd_h.addWidget(self.snd_lbl, 1)
        snd_h.addWidget(prev_btn)
        snd_h.addWidget(choose_btn)
        vl_snd.addLayout(snd_h)

        lay.addWidget(grp_snd)

        # ──Splash ─────────────────────────────────────────────────────────
        grp_spl, vl_spl = self._section("Splash Screen")
        grp_spl.setStyleSheet("color:white; font-size: 12px;")

        self.splash_cb = QtWidgets.QCheckBox("Show splash screen on launch")
        self.splash_cb.setChecked(self.get("splash_enabled", True))
        self.splash_cb.toggled.connect(
            lambda v: self._set("splash_enabled", v))
        vl_spl.addWidget(self.splash_cb)

        self.dur_spin = QtWidgets.QSpinBox()
        self.dur_spin.setRange(1, 20000)
        self.dur_spin.setSingleStep(100)
        self.dur_spin.setSuffix("  ms")
        self.dur_spin.setValue(self.get("splash_duration_ms", 100))
        self.dur_spin.setFixedWidth(130)
        self.dur_spin.valueChanged.connect(
            lambda v: self._set("splash_duration_ms", v))
        vl_spl.addLayout(self._row(
            "Splash Duration", self.dur_spin,
            tip="How long the splash is shown (milliseconds)"
        ))

        lay.addWidget(grp_spl)

        # ──Reset ───────────────────────────────────────────────────────────
        grp_rst, vl_rst = self._section("About & Reset")
        grp_rst.setStyleSheet("color:white; font-size: 12px;")

        cfg_lbl = QtWidgets.QLabel("Config:  " + self._cfg_path)
        cfg_lbl.setWordWrap(True)
        cfg_lbl.setStyleSheet("color:#555; font-size:10px;")
        vl_rst.addWidget(cfg_lbl)

        reset_btn = QtWidgets.QPushButton("Reset All Settings to Defaults")
        reset_btn.setStyleSheet("color:white; font-size: 12px;")
        reset_btn.setObjectName("danger")
        reset_btn.clicked.connect(self._reset_all)
        vl_rst.addWidget(reset_btn)

        lay.addWidget(grp_rst)
        lay.addStretch()

    # ── Slots ─────────────────────────────────────────────────────────────────
    def _apply_theme(self, name):
        """Apply theme instantly to the whole window & save choice."""
        self._set("theme", name)
        for n, b in self._theme_btns.items():
            b.setChecked(n == name)
        win = self.window()
        if win:
            win.setStyleSheet(build_stylesheet(name))

    def _browse_tools_dir(self):
        d = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select Tools Directory",
            self.tools_dir_edit.text() or os.path.expanduser("~/.nuke")
        )
        if d:
            self.tools_dir_edit.setText(d)
            self._set("default_tools_dir", d)

    def _refresh_snd_lbl(self):
        try:
            from sound_utils import get_chosen
            p = get_chosen()
            if p and os.path.isfile(p):
                self.snd_lbl.setText(os.path.basename(p))
                self.snd_lbl.setStyleSheet("color:#a0a0a0; font-size:11px;")
            else:
                self.snd_lbl.setText("No sound")
                self.snd_lbl.setStyleSheet("color:#555; font-size:11px;")
        except ImportError:
            self.snd_lbl.setText("sound_utils.py not found")
            self.snd_lbl.setStyleSheet("color:#886633; font-size:11px;")
        except Exception:
            self.snd_lbl.setText("—")
            self.snd_lbl.setStyleSheet("color:#555; font-size:11px;")

    def _preview_sound(self):
        try:
            from sound_utils import play_async
            play_async()
        except Exception:
            pass

    def _choose_sound(self):
        try:
            from sound_utils import show_picker
            show_picker(self)
            self._refresh_snd_lbl()
        except ImportError:
            QtWidgets.QMessageBox.warning(
                self, "Missing File",
                "sound_utils.py not found.\n"
                "Add it and a  sounds/  folder next to tool_manager_ui.py."
            )
        except Exception as e:
            QtWidgets.QMessageBox.warning(self, "Sound Error", str(e))

    def _reset_all(self):
        # PySide6 moved Yes/No into StandardButton enum
        try:
            _Yes = QtWidgets.QMessageBox.StandardButton.Yes
            _No  = QtWidgets.QMessageBox.StandardButton.No
        except AttributeError:
            _Yes = QtWidgets.QMessageBox.Yes
            _No  = QtWidgets.QMessageBox.No

        r = QtWidgets.QMessageBox.question(
            self, "Reset Settings",
            "Reset ALL settings to defaults?\nThis cannot be undone.",
            _Yes | _No
        )
        if r != _Yes:
            return

        # 1. Clear saved config
        self._cfg = {}
        self._save_cfg()

        # 2. Reset every UI widget to its default value

        # Theme -> Dark Amber
        self._apply_theme(_DEFAULT_THEME)

        # General text fields
        self.nuke_ver_edit.setText("")
        self.tools_dir_edit.setText("")

        # Checkboxes - block signals so _set() is not triggered during reset
        for cb, default in [
            (self.write_init_cb,   True),
            (self.overwrite_cb,    False),
            (self.sound_enable_cb, True),
            (self.splash_cb,       True),
        ]:
            cb.blockSignals(True)
            cb.setChecked(default)
            cb.blockSignals(False)

        # Splash duration spinbox
        self.dur_spin.blockSignals(True)
        self.dur_spin.setValue(1800)
        self.dur_spin.blockSignals(False)

        # Refresh sound label
        self._refresh_snd_lbl()

        QtWidgets.QMessageBox.information(
            self, "Reset Complete",
            "All settings have been reset to defaults."
        )


# ══════════════════════════════════════════════════════════════════════════════
# MAIN WINDOW
# ══════════════════════════════════════════════════════════════════════════════

class NukeToolsManager(QtWidgets.QMainWindow):

    _ICON_DIR = os.path.dirname(os.path.abspath(__file__))

    @classmethod
    def _make_qicon(cls):
        """Build a QIcon with all available resolutions."""
        icon = QtGui.QIcon()
        for size in (16, 32, 48, 64, 128, 256):
            path = os.path.join(cls._ICON_DIR, f"icon_{size}.png")
            if os.path.isfile(path):
                icon.addFile(path, QtCore.QSize(size, size))
        return icon

    def __init__(self, parent=None):
        # Qt.Window  → own title bar + taskbar button + its own icon,
        # even when launched as a child of Nuke's main window.
        # Qt.WindowStaysOnTopHint removed so it doesn't always sit on top.
        super().__init__(parent, Qt.Window)
        self.setWindowTitle("NK Tools Manager | By: Author Nitin Kashyap")
        self.resize(980, 1060)
        # ── Load saved theme on startup ──────────────────────────────────────

        # import json as _j
        # _cfg_p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "settings.cfg")
        # _theme = _DEFAULT_THEME
        # try:
        #     _theme = _j.load(open(_cfg_p, "r", encoding="utf-8")).get("theme", _DEFAULT_THEME)
        # except Exception:
        #     pass
        # self.setStyleSheet(build_stylesheet(_theme))


        # Build icon from every available resolution
        app_icon = self._make_qicon()

        # Set icon on THIS window — do NOT touch app.setWindowIcon()
        # because inside Nuke that would overwrite Nuke's own taskbar icon.
        self.setWindowIcon(app_icon)

        # Force the icon onto the window handle AFTER the native handle exists
        # (needed on Windows so the taskbar shows our icon, not Nuke's)
        self._app_icon = app_icon   # keep reference alive

        self._build_ui()

    def _build_ui(self):
        central = QtWidgets.QWidget()
        self.setCentralWidget(central)
        root = QtWidgets.QVBoxLayout(central)
        root.setContentsMargins(16, 12, 16, 12)
        root.setSpacing(10)

        # ── Header ─────────────────────────────────────────────────────────────
        hdr = QtWidgets.QHBoxLayout()

        HEADER_LOGO_SIZE = 128          # ← change this one number to resize the header icon

        logo_lbl  = QtWidgets.QLabel()
        logo_path = os.path.join(self._ICON_DIR, "logo", "icon_256.png")
        if os.path.isfile(logo_path):
            pix = QtGui.QPixmap(logo_path).scaled(
                HEADER_LOGO_SIZE, HEADER_LOGO_SIZE,
                Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            logo_lbl.setPixmap(pix)
        logo_lbl.setFixedSize(HEADER_LOGO_SIZE, HEADER_LOGO_SIZE)
        logo_lbl.setAlignment(Qt.AlignCenter)
        hdr.addWidget(logo_lbl)
        hdr.addSpacing(14)
        # ... inside your setup UI method ...

        title_lbl = QtWidgets.QLabel("NK Tools Manager")
        title_lbl.setAlignment(QtCore.Qt.AlignCenter)
        title_lbl.setStyleSheet("""
            QLabel {
                /* Inverted: y1:0 to y2:1 */
                color: qlineargradient(y1:0, x1:0, y2:1, x2:0, 
                                        stop:0 #33CBFF, stop:1 #00455D);
                font-size: 45px;
                font-weight: bold;
                font-style: italic;
                border-radius: 10px;
                padding: 10px;
            }
        """)

        # Create the shadow effect
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(3)          # How soft the shadow looks
        shadow.setXOffset(64)             # Horizontal distance
        shadow.setYOffset(3)             # Vertical distance
        shadow.setColor(QColor(0, 0, 0, 260)) # Black with transparency

        # Apply the effect to the label
        title_lbl.setGraphicsEffect(shadow)

        hdr.addWidget(title_lbl)

        badge = QtWidgets.QLabel(f"PySide{PYSIDE}")
        badge.setObjectName("badge")
        hdr.addWidget(badge)
        root.addLayout(hdr)

        div = QtWidgets.QFrame()
        div.setFrameShape(QtWidgets.QFrame.HLine)
        root.addWidget(div)

        # ── Shared log ─────────────────────────────────────────────────────────
        self.log_widget = LogWidget()
        self.log_widget.setMaximumHeight(120)

        # ── Tabs ───────────────────────────────────────────────────────────────
        self.tabs = QtWidgets.QTabWidget()
        self.folder_install_tab = FolderInstallTab(self.log_widget)
        self.install_tab        = InstallTab(self.log_widget)
        self.zip_tab            = ZipTab(self.log_widget,icon_dir=self._ICON_DIR)
        self.installed_tab      = InstalledTab(self.log_widget)
        self.nuke_tab           = NukeTab(self.log_widget)
        self.about_tab          = AboutTab()
        self.settings_tab       = SettingsTab()

        self.tabs.addTab(self.folder_install_tab, "  Install Folder  ")
        self.tabs.addTab(self.install_tab,        "  Install Zip  ")
        self.tabs.addTab(self.zip_tab,            "  Zip / Export  ")
        self.tabs.addTab(self.installed_tab,      "  Installed Tools  ")
        self.tabs.addTab(self.nuke_tab,           "  Nuke Utils  ")
        self.tabs.addTab(self.about_tab,          "  About  ")
        self.tabs.addTab(self.settings_tab,       "  ⚙  Settings  ")
        self.tabs.currentChanged.connect(self._on_tab_change)
        root.addWidget(self.tabs, 1)

        # ── Log panel ──────────────────────────────────────────────────────────
        base_dir = os.path.dirname(os.path.abspath(__file__))  # add this line

        log_grp = QtWidgets.QGroupBox("Log")
        log_l   = QtWidgets.QVBoxLayout(log_grp)
        log_l.addWidget(self.log_widget)
        clr_l = QtWidgets.QHBoxLayout()
        clr_l.addStretch()  # push button to the right
        # Clear Log button
        self.clr = QtWidgets.QPushButton("Clear Log")
        icon_path = os.path.join(base_dir, "icons", "log.png")
        self.clr.setIcon(QtGui.QIcon(icon_path))
        self.clr.setIconSize(QtCore.QSize(24, 24))  # adjust size as needed
        self.clr.setObjectName("small")
        self.clr.clicked.connect(self.log_widget.clear_log)
        clr_l.addWidget(self.clr)
        log_l.addLayout(clr_l)
        root.addWidget(log_grp)

        # Initial log messages
        self.log_widget.log("Nuke Tools Manager ready.", 'title')
        self.log_widget.log(f"PySide{PYSIDE} | Tools dir: {TOOLS_DIR}", 'debug')

    def _on_tab_change(self, idx):
        if self.tabs.widget(idx) is self.installed_tab:
            self.installed_tab.refresh()


# ══════════════════════════════════════════════════════════════════════════════
# PUBLIC LAUNCHER
# ══════════════════════════════════════════════════════════════════════════════

_window_instance = None


def show(parent=None):
    """
    Launch the Nuke Tools Manager window.
    Safe to call from Nuke's Script Editor or menu.py.
    Returns the QMainWindow instance.
    """
    global _window_instance

    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)

    if _window_instance is None or not _window_instance.isVisible():
        _window_instance = NukeToolsManager(parent)

    _window_instance.show()
    _window_instance.raise_()
    _window_instance.activateWindow()

    # Re-apply icon AFTER show() so the native window handle exists on Windows.
    # This ensures the taskbar and title bar both show our icon, not Nuke's.
    _window_instance.setWindowIcon(_window_instance._app_icon)

    return _window_instance


def show_tab(index: int):
    """Open the manager and jump to a specific tab (0-4).
    0 = Install Folder, 1 = Install Zip, 2 = Zip/Export,
    3 = Installed Tools, 4 = Nuke Utils
    """
    win = show()
    win.tabs.setCurrentIndex(index)
    return win


# ── Standalone entry point ─────────────────────────────────────────────────────

if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = show()
    sys.exit(_exec(app))
